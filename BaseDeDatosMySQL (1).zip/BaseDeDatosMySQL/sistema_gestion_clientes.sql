-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: sistema_gestion
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave_acta` varchar(20) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `num_trabajadores` int NOT NULL,
  `giro` varchar(50) NOT NULL,
  `num_sucursales` int NOT NULL,
  `monto_inicial` decimal(15,2) NOT NULL,
  `porcentaje_ganancia` varchar(10) NOT NULL,
  `num_cuenta` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave_acta` (`clave_acta`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (108,'ACTA12345','Grupo Industrial Jalisco',7,'Manufactura',3,1000000.00,'15.0%','1234567890'),(109,'ACTA23456','Tecnologias Avanzadas SA',12,'TecnologÃ­a',5,2500000.00,'18.5%','9876543210'),(110,'ACTA34567','Constructora Nacional',24,'Construcción',8,3500000.00,'20.0%','5678901234'),(111,'ACTA45678','Alimentos del Valle',15,'Alimentos',4,1200000.00,'12.0%','3456789012'),(112,'ACTA67890','Salud',18,'Salud',6,2200000.00,'17.0%','4567890123'),(113,'ACTA78901','Educacion Futura',11,'Educación',3,950000.00,'14.0%','2345678901'),(114,'ACTA89012','Comercializadora Global',22,'Comercio',7,2800000.00,'19.0%','8901234567'),(115,'ACTA90123','Energia Renovable SA',14,'Manufactura',4,1500000.00,'16.5%','6789012345'),(116,'ACTA01234','Transportes Rapidos',19,'Transporte',5,2100000.00,'18.0%','9012345678'),(117,'ACTA20055','Walmart',50,'Ventas',10,1000000.00,'20','20000'),(128,'ACTA30000','Salud Omega 0',38,'Manufactura',8,7190151.96,'10.70%','8447116860'),(129,'ACTA30001','Empresa Alpha 1',21,'Comercio',1,9217814.11,'14.00%','6233495143'),(130,'ACTA30002','Salud Omega 2',26,'Comercio',9,2139331.27,'17.30%','9724194233'),(131,'ACTA30003','Industria Delta 3',23,'Educacion',3,1191968.60,'16.20%','2449385728'),(132,'ACTA30004','Industria Delta 4',60,'Alimentos',2,7243696.72,'12.60%','6366975826'),(133,'ACTA30005','Empresa Alpha 5',16,'Transporte',1,9197698.13,'13.20%','7526373188'),(134,'ACTA30006','Comercial Zeta 6',47,'Transporte',6,8990656.25,'18.50%','8607637801'),(135,'ACTA30007','Salud Omega 7',52,'Salud',4,9441662.66,'11.80%','5718681738'),(136,'ACTA30008','Corp Beta 8',48,'Manufactura',6,3067449.54,'17.40%','9217906229'),(137,'ACTA30009','Tecnologia Apsilon 9',12,'Manufactura',3,7739311.09,'20.00%','7389058101'),(138,'ACTA30010','Tecnologia Apsilon 10',54,'Ventas',2,8635220.37,'20.00%','4173650723'),(139,'ACTA30011','Comercial Zeta 11',59,'Tecnologi­a',1,2469733.70,'16.80%','3006543880'),(140,'ACTA30012','Corp Beta 12',12,'Manufactura',6,9535258.39,'11.30%','2593755433'),(141,'ACTA30013','Tecnologia Apsilon 13',27,'Comercio',3,5090214.64,'17.50%','3402535030'),(142,'ACTA30014','Servicios Gamma 14',51,'Tecnologi­a',1,8824804.22,'12.90%','7135079888'),(143,'ACTA30015','Comercial Zeta 15',38,'Comercio',9,6565565.44,'13.30%','6178176023'),(144,'ACTA30016','Tecnologia Apsilon 16',23,'Ventas',7,9921320.35,'16.70%','9182458264'),(145,'ACTA30017','Empresa Alpha 17',21,'Salud',3,991295.74,'17.50%','6030641582'),(146,'ACTA30018','Salud Omega 18',28,'Educacion',7,2161714.41,'10.70%','9801905718'),(147,'ACTA30019','Corp Beta 19',38,'Comercio',7,6104961.80,'19.20%','9529475976'),(148,'ACTA30020','Salud Omega 20',36,'Manufactura',3,2629678.44,'14.10%','3786390653'),(149,'ACTA30021','Servicios Gamma 21',27,'Ventas',4,5925887.93,'17.60%','1052694507'),(150,'ACTA30022','Corp Beta 22',44,'Tecnologi­a',3,1348018.92,'15.10%','5916238519'),(151,'ACTA30023','Corp Beta 23',48,'Comercio',10,2323571.76,'11.30%','2825591177'),(152,'ACTA30024','Servicios Gamma 24',51,'Manufactura',4,2408140.66,'12.30%','7967165875'),(153,'ACTA30025','Empresa Alpha 25',33,'Alimentos',10,8604555.52,'17.30%','9909510186'),(154,'ACTA30026','Comercial Zeta 26',15,'Ventas',7,5881729.86,'17.90%','6282635857'),(155,'ACTA30027','Salud Omega 27',11,'Tecnologi­a',8,2955719.44,'13.80%','7388115821'),(156,'ACTA30028','Comercial Zeta 28',50,'Tecnologi­a',9,1149486.12,'18.80%','4692829324'),(157,'ACTA30029','Empresa Alpha 29',27,'Tecnologi­a',4,1901331.54,'10.40%','9384728119'),(158,'ACTA30030','Corp Beta 30',39,'Comercio',6,3528308.33,'14.40%','4964509162'),(159,'ACTA30031','Corp Beta 31',49,'Educacion',1,7962464.78,'10.70%','9135214938'),(160,'ACTA30032','Salud Omega 32',8,'Transporte',9,8657776.34,'10.60%','5653526165'),(161,'ACTA30033','Comercial Zeta 33',42,'Ventas',3,8850125.81,'11.80%','6649225388'),(162,'ACTA30034','Tecnologia Apsilon 34',30,'Construccion',10,4758592.87,'14.10%','1675497089'),(163,'ACTA30035','Corp Beta 35',18,'Alimentos',4,1094567.53,'19.20%','2535793632'),(164,'ACTA30036','Tecnologia Apsilon 36',12,'Transporte',2,8594479.44,'12.80%','2898950913'),(165,'ACTA30037','Servicios Gamma 37',50,'Comercio',1,8160292.58,'11.60%','5084375724'),(166,'ACTA30038','Industria Delta 38',12,'Salud',3,1050367.12,'14.20%','7538934945'),(167,'ACTA30039','Corp Beta 39',28,'Construccion',7,4128151.13,'18.40%','9552549109'),(168,'ACTA30040','Corp Beta 40',57,'Ventas',6,8653554.65,'14.90%','8485778248'),(169,'ACTA30041','Servicios Gamma 41',20,'Manufactura',8,9600386.34,'18.10%','3591439742'),(170,'ACTA30042','Tecnologia Apsilon 42',35,'Tecnologia',7,9274584.23,'15.10%','5982382529'),(171,'ACTA30043','Comercial Zeta 43',22,'Transporte',10,2965780.19,'11.80%','9448320059'),(172,'ACTA30044','Servicios Gamma 44',48,'Construccion',1,6867019.21,'18.40%','1081667717'),(173,'ACTA30045','Industria Delta 45',13,'Comercio',2,835054.15,'11.80%','8979909689'),(174,'ACTA30046','Salud Omega 46',8,'Ventas',7,3857381.76,'20.60%','3386262958'),(175,'ACTA30047','Tecnologia Apsilon 47',31,'Manufactura',1,9431382.64,'10.10%','1655008136'),(176,'ACTA30048','Comercial Zeta 48',54,'Educacion',9,3851654.28,'18.80%','5510009618'),(177,'ACTA30049','Comercial Zeta 49',28,'Salud',3,8771065.82,'15.50%','2007102940');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-09  2:35:20
