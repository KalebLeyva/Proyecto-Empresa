-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: sistema_gestion
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `empleado`
--

DROP TABLE IF EXISTS `empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleado` (
  `id` int NOT NULL AUTO_INCREMENT,
  `curp` varchar(25) DEFAULT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `num_cuenta` varchar(20) NOT NULL,
  `tipo_banco` varchar(50) DEFAULT NULL,
  `socio` varchar(2) DEFAULT NULL,
  `empleado_de` varchar(20) NOT NULL,
  `salario` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `curp` (`curp`),
  KEY `empleado_ibfk_2` (`empleado_de`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleado`
--

LOCK TABLES `empleado` WRITE;
/*!40000 ALTER TABLE `empleado` DISABLE KEYS */;
INSERT INTO `empleado` VALUES (12,'MOLE19273HOCNRDA5','Efrain','Luna Espina','efragod@email.com','55321987654','Calle Roble 9','1100332244','Mercado Pago','Sí','ACTA12345',17500.25),(13,'LESK051005JLYA5','abisai','Parra Lerma','kalebleyva01@gmail.com','9512026893','col. del maestro 602','987456321','Banorte','si','Acta20055',1500.00),(14,'GARCJ90010IHICLRN03','Juan','Garcia Ramirez','juangarcia@gmail.com','5512345678','Calle Falsa 123','11223344','BBVA','Sí','ACTA12345',15000.50),(15,'LOPEM880215HICLRP04','Maria','Lopez Martinez','marialopez@email.com','5512345679','Avenida Siempre Viva 742','11223345','Santander','Sí','ACTA12345',16000.75),(16,'PERAJ850320HICLRN05','Pedro','Perez Rami­rez','pedroperez@email.com','5512345680','Av. Revolucion 456','11223346','Banamex','No','ACTA23456',14500.25),(17,'RODAM870415HICLRP06','Ana','Rodriguez Martinez','anarodriguez@email.com','5512345681','Calle Juarez 789','11223347','HSBC','Sí','ACTA23456',15500.00),(18,'GONJL820530HICLRN07','Luis','Gonzalez Lopez','luisgonzalez@email.com','5512345682','Paseo de la Reforma 101','11223348','Scotiabank','No','ACTA34567',14200.50),(19,'MARSF830625HICLRP08','Sofia','Martinez Flores','sofiamartinez@email.com','5512345683','Insurgentes 202','11223349','Banorte','Sí','ACTA34567',16800.75),(20,'HERCJ840710HICLRN09','Carlos','Hernandez Jimenez','carloshernandez@email.com','5512345684','Av. Universidad 303','11223350','BBVA','No','ACTA45678',13500.00),(21,'FLOPA850805HICLRP10','Patricia','Flores Perez','patriciaflores@email.com','5512345685','Calle Morelos 404','11223351','Santander','Sí','ACTA45678',15700.25),(22,'RAMJG860930HICLRN11','Jorge','Rami­rez Gomez','jorgeramirez@email.com','5512345686','Av. Hidalgo 505','11223352','Banamex','No','ACTA56789',14000.50),(23,'GARML871025HICLRP12','Laura','Garcia Morales','lauragarcia@email.com','5512345687','Calle Zaragoza 606','11223353','HSBC','Sí','ACTA56789',16200.75),(24,'PERA850101HDFPLD03','Pedro','Perez Ramirez','pedropere...','5512345...','Av Revol...','11223346','Banamex','No','ACTA123...',17000.00),(25,'RAMJ980101HDFJGR09','Jorge','Ramirez Gonzalez','jorgeram...','5512345...','Av Hidalgo...','11223352','Banamex','No','ACTA4567...',14000.00),(26,'GEN0000HDFLNS00','RaÃºl','PÃ©rez Flores','raÃºl.pÃ©rez0@correo.com','5535669129','Av. Central #88','31933024','Scotiabank','No','ACTA89012',15899.28),(27,'GEN0001HDFLNS01','Laura','LÃ³pez RamÃ­rez','laura.lÃ³pez1@correo.com','5574648468','Calle Independencia #582','26231565','HSBC','No','ACTA89012',14609.52),(28,'GEN0003HDFLNS03','RaÃºl','Flores PÃ©rez','raÃºl.flores3@correo.com','5515466447','Calle Reforma #562','64618152','HSBC','No','ACTA89012',17289.20),(29,'GEN0004HDFLNS04','Carlos','HernÃ¡ndez GonzÃ¡lez','carlos.hernÃ¡ndez4@correo.com','5522234987','Calle Reforma #812','89391172','HSBC','No','ACTA12345',13535.70),(30,'GEN0009HDFLNS09','Carlos','GonzÃ¡lez PÃ©rez','carlos.gonzÃ¡lez9@correo.com','5538911533','Av. Central #603','67704328','Banamex','No','ACTA67890',17325.76),(31,'GEN0010HDFLNS10','Luis','GonzÃ¡lez GonzÃ¡lez','luis.gonzÃ¡lez10@correo.com','5515887224','Calle Reforma #799','24936280','Scotiabank','No','ACTA34567',12565.15),(32,'GEN0011HDFLNS11','LucÃ­a','Santos Santos','lucÃ­a.santos11@correo.com','5518598317','Av. Insurgentes #911','41304117','BBVA','No','ACTA12345',14089.79),(33,'GEN0013HDFLNS13','Diego','Santos PÃ©rez','diego.santos13@correo.com','5563296614','Av. Insurgentes #756','22693242','Banorte','No','ACTA34567',12197.17),(34,'GEN0015HDFLNS15','Mario','PÃ©rez Santos','mario.pÃ©rez15@correo.com','5589949680','Av. Central #491','93145532','Santander','No','ACTA89012',16555.53),(35,'GEN0018HDFLNS18','SofÃ­a','Flores MartÃ­nez','sofÃ­a.flores18@correo.com','5536294706','Av. Insurgentes #271','97697595','HSBC','No','ACTA34567',17407.24),(36,'GEN0024HDFLNS24','Diego','Santos GonzÃ¡lez','diego.santos24@correo.com','5586256253','Av. Central #366','23721590','Banamex','No','ACTA12345',19898.06),(37,'GEN0025HDFLNS25','Ana','RamÃ­rez LÃ³pez','ana.ramÃ­rez25@correo.com','5541269439','Calle Reforma #527','65050764','BBVA','No','ACTA67890',12566.63),(38,'GEN0029HDFLNS29','Elena','HernÃ¡ndez RamÃ­rez','elena.hernÃ¡ndez29@correo.com','5562761331','Av. Central #832','32015777','Banamex','No','ACTA12345',12974.80),(39,'GEN0030HDFLNS30','Diego','MartÃ­nez RamÃ­rez','diego.martÃ­nez30@correo.com','5569850901','Calle Reforma #124','26960630','Santander','No','ACTA67890',14646.12),(40,'GEN0032HDFLNS32','Ana','Flores MartÃ­nez','ana.flores32@correo.com','5587553007','Av. Insurgentes #22','97875037','Santander','No','ACTA12345',12489.24),(41,'GEN0034HDFLNS34','Laura','GonzÃ¡lez PÃ©rez','laura.gonzÃ¡lez34@correo.com','5545804454','Calle Reforma #761','25570409','Scotiabank','No','ACTA34567',13362.45),(42,'GEN0035HDFLNS35','Ana','LÃ³pez MartÃ­nez','ana.lÃ³pez35@correo.com','5518833848','Calle 5 de Mayo #755','34491175','Scotiabank','No','ACTA67890',17225.73),(43,'GEN0040HDFLNS40','Laura','RamÃ­rez Santos','laura.ramÃ­rez40@correo.com','5545486193','Calle Independencia #727','43234351','Santander','No','ACTA12345',13329.63),(44,'GEN0042HDFLNS42','Elena','GonzÃ¡lez MartÃ­nez','elena.gonzÃ¡lez42@correo.com','5541799783','Calle Reforma #604','46263597','Banorte','No','ACTA45678',12033.44),(45,'GEN0043HDFLNS43','Mario','Flores RamÃ­rez','mario.flores43@correo.com','5592209122','Calle 5 de Mayo #349','76938616','BBVA','No','ACTA89012',19297.64),(46,'GEN0046HDFLNS46','Luis','Santos MartÃ­nez','luis.santos46@correo.com','5593408299','Calle Reforma #572','13261026','Banamex','No','ACTA45678',18303.13),(47,'GEN0047HDFLNS47','RaÃºl','PÃ©rez HernÃ¡ndez','raÃºl.pÃ©rez47@correo.com','5518118640','Calle Reforma #8','55952613','Scotiabank','No','ACTA45678',19434.32),(48,'GEN0049HDFLNS49','LucÃ­a','Flores GonzÃ¡lez','lucÃ­a.flores49@correo.com','5592147295','Calle Independencia #900','23139876','Santander','No','ACTA20055',19587.85);
/*!40000 ALTER TABLE `empleado` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-09  2:35:20
