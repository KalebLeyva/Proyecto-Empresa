-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: sistema_gestion
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `empleado`
--

DROP TABLE IF EXISTS `empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleado` (
  `id` int NOT NULL AUTO_INCREMENT,
  `curp` varchar(25) DEFAULT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `num_cuenta` varchar(20) NOT NULL,
  `tipo_banco` varchar(50) DEFAULT NULL,
  `socio` varchar(2) DEFAULT NULL,
  `empleado_de` varchar(20) NOT NULL,
  `salario` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `curp` (`curp`),
  KEY `empleado_ibfk_2` (`empleado_de`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleado`
--

LOCK TABLES `empleado` WRITE;
/*!40000 ALTER TABLE `empleado` DISABLE KEYS */;
INSERT INTO `empleado` VALUES (12,'MOLE19273HOCNRDA5','Efrain','Luna Espina','efragod@email.com','55321987654','Calle Roble 9','1100332244','Mercado Pago','Sí','ACTA12345',17500.25),(13,'LESK051005JLYA5','abisai','Parra Lerma','kalebleyva01@gmail.com','9512026893','col. del maestro 602','987456321','Banorte','si','Acta20055',1500.00),(14,'GARCJ90010IHICLRN03','Juan','Garcia Ramirez','juangarcia@gmail.com','5512345678','Calle Falsa 123','11223344','BBVA','Sí','ACTA12345',15000.50),(15,'LOPEM880215HICLRP04','Maria','Lopez Martinez','marialopez@email.com','5512345679','Avenida Siempre Viva 742','11223345','Santander','Sí','ACTA12345',16000.75),(16,'PERAJ850320HICLRN05','Pedro','Perez Rami­rez','pedroperez@email.com','5512345680','Av. Revolucion 456','11223346','Banamex','No','ACTA23456',14500.25),(17,'RODAM870415HICLRP06','Ana','Rodriguez Martinez','anarodriguez@email.com','5512345681','Calle Juarez 789','11223347','HSBC','Sí','ACTA23456',15500.00),(18,'GONJL820530HICLRN07','Luis','Gonzalez Lopez','luisgonzalez@email.com','5512345682','Paseo de la Reforma 101','11223348','Scotiabank','No','ACTA34567',14200.50),(19,'MARSF830625HICLRP08','Sofia','Martinez Flores','sofiamartinez@email.com','5512345683','Insurgentes 202','11223349','Banorte','Sí','ACTA34567',16800.75),(20,'HERCJ840710HICLRN09','Carlos','Hernandez Jimenez','carloshernandez@email.com','5512345684','Av. Universidad 303','11223350','BBVA','No','ACTA45678',13500.00),(21,'FLOPA850805HICLRP10','Patricia','Flores Perez','patriciaflores@email.com','5512345685','Calle Morelos 404','11223351','Santander','Sí','ACTA45678',15700.25),(22,'RAMJG860930HICLRN11','Jorge','Rami­rez Gomez','jorgeramirez@email.com','5512345686','Av. Hidalgo 505','11223352','Banamex','No','ACTA56789',14000.50),(23,'GARML871025HICLRP12','Laura','Garcia Morales','lauragarcia@email.com','5512345687','Calle Zaragoza 606','11223353','HSBC','Sí','ACTA56789',16200.75);
/*!40000 ALTER TABLE `empleado` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-08 22:50:05
