-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: sistema_gestion
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave_acta` varchar(20) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `num_trabajadores` int NOT NULL,
  `giro` varchar(50) NOT NULL,
  `num_sucursales` int NOT NULL,
  `monto_inicial` decimal(15,2) NOT NULL,
  `porcentaje_ganancia` varchar(10) NOT NULL,
  `num_cuenta` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave_acta` (`clave_acta`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (108,'ACTA12345','Grupo Industrial Jalisco',7,'Manufactura',3,1000000.00,'15.0%','1234567890'),(109,'ACTA23456','Tecnologias Avanzadas SA',12,'TecnologÃ­a',5,2500000.00,'18.5%','9876543210'),(110,'ACTA34567','Constructora Nacional',24,'Construcción',8,3500000.00,'20.0%','5678901234'),(111,'ACTA45678','Alimentos del Valle',15,'Alimentos',4,1200000.00,'12.0%','3456789012'),(112,'ACTA67890','Salud',18,'Salud',6,2200000.00,'17.0%','4567890123'),(113,'ACTA78901','Educacion Futura',11,'Educación',3,950000.00,'14.0%','2345678901'),(114,'ACTA89012','Comercializadora Global',22,'Comercio',7,2800000.00,'19.0%','8901234567'),(115,'ACTA90123','Energia Renovable SA',14,'Manufactura',4,1500000.00,'16.5%','6789012345'),(116,'ACTA01234','Transportes Rapidos',19,'Transporte',5,2100000.00,'18.0%','9012345678'),(117,'ACTA20055','Walmart',50,'Ventas',10,1000000.00,'20','20000');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-08 22:50:06
