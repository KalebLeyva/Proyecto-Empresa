/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unidad2;
import java.util.Date;
/**
 * Representa un usuario del sistema con sus datos personales y de acceso.
 * Contiene información como nombre, apellidos, correo electrónico, contraseña,
 * fecha de nacimiento, sexo y rol dentro del sistema.
 * 
 * @author kaleb
 */
public class Usuario {
    private String nombre;
    private String apellidoP;
    private String apellidoM;
    private String correo;
    private String contraseña;
    private Date fechaNacimiento;
    private boolean sexo;
     private String rol;

    // Constructor de la clase Usuario
    public Usuario(String nombre, String apellidoP, String apellidoM, String correo, String contraseña, Date fechaNacimiento, boolean sexo, String rol) {
        this.nombre = nombre;
        this.apellidoP = apellidoP;
        this.apellidoM = apellidoM;
        this.contraseña = contraseña;
        this.fechaNacimiento = fechaNacimiento;
        this.sexo = sexo;
        this.correo = correo;
        this.rol = rol;
    }


    public String getNombre() {return nombre;}
    public void setNombre(String nombre) {this.nombre = nombre;}

    public String getApellidoP() {return apellidoP;}
    public void setApellidoP(String apellidoP) {this.apellidoP = apellidoP;}

    public String getApellidoM() {return apellidoM;}
    public void setApellidoM(String apellidoM) {this.apellidoM = apellidoM;}
    
    public String getCorreo(){return correo;}
    public void setCorreo(String correo){this.correo=correo;}

    public String getContraseña() {return contraseña;}
    public void setContraseña(String contraseña) {this.contraseña = contraseña;}

    public Date getFechaNacimiento() {return fechaNacimiento;}
    public void setFechaNacimiento(Date fechaNacimiento) {this.fechaNacimiento = fechaNacimiento;}

    public boolean isSexo() {return sexo;}
    public void setSexo(boolean sexo) {this.sexo = sexo;}
    
    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    // Método para mostrar la información del usuario
    @Override
    public String toString() {
        return "Usuario{" +
                "nombre='" + nombre + '\'' +
                ", apellidoP='" + apellidoP + '\'' +
                ", apellidoM='" + apellidoM + '\'' +
                ", correo='" + correo + '\'' +
                ", rol='" + rol + '\'' +
                ", fechaNacimiento=" + fechaNacimiento +
                ", sexo=" + (sexo ? "Masculino" : "Femenino") +
                '}';
    }
}