/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package unidad2;
import java.awt.BorderLayout;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
/**
 * Clase que representa una ventana para agregar nuevos registros de diferentes tipos
 * (Cliente, Empleado, AdmFondo, AsociadoCivil) a un sistema.
 * La ventana genera dinámicamente los campos necesarios según el tipo de registro
 * y permite guardar la información capturada mediante DAO correspondientes.
 * 
 * Esta clase extiende {@code javax.swing.JFrame}.
 * 
 * @author MSI
 */
public class AgregarDatos extends javax.swing.JFrame {
    /**
     * Mapa que contiene los campos de entrada con su etiqueta como clave.
     */
    private Map<String, JComponent> campos = new HashMap<>();
    /**
     * Tipo de registro que se está agregando (Cliente, Empleado, AdmFondo, AsociadoCivil).
     */
    private String tipoRegistro;
    private SistemaTablasSimple sistema;
    /**
     * Constructor que crea la ventana para agregar datos de un tipo específico.
     * 
     * @param tipoRegistro El tipo de registro a agregar ("Cliente", "Empleado", "AdmFondo", "AsociadoCivil").
     * @param sistema Referencia al sistema principal para actualizar datos tras guardar.
     */
    public AgregarDatos(String tipoRegistro, SistemaTablasSimple sistema) {
        this.tipoRegistro = tipoRegistro;
        this.sistema = sistema;
        initComponents();
        customizeComponents();
        getContentPane().setBackground(new Color(1, 19, 31));
    }
    /**
     * Inicializa y personaliza los componentes gráficos de la ventana,
     * generando dinámicamente los campos de entrada según el tipo de registro,
     * configurando el layout y los botones.
     */
private void customizeComponents() {
        getContentPane().setBackground(new Color(1, 19, 31));
        setTitle("Agregar nuevo " + tipoRegistro);
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        panelCampos.setLayout(new java.awt.GridLayout(0, 2, 5, 5));
        
        switch(tipoRegistro) {
            case "Cliente":
                agregarCampo("Clave Acta:", new JTextField());
                agregarCampo("Nombre:", new JTextField());
                agregarCampo("Núm. Trabajadores:", new JTextField());
                agregarCampo("Giro:", new JTextField());
                agregarCampo("Núm. Sucursales:", new JTextField());
                agregarCampo("Monto Inicial:", new JTextField());
                agregarCampo("% Ganancia:", new JTextField());
                agregarCampo("Núm. Cuenta:", new JTextField());
                break;
                
            case "Empleado":
                agregarCampo("CURP:", new JTextField());
                agregarCampo("Nombre:", new JTextField());
                agregarCampo("Apellidos:", new JTextField());
                agregarCampo("Correo:", new JTextField());
                agregarCampo("Teléfono:", new JTextField());
                agregarCampo("Dirección:", new JTextField());
                agregarCampo("Núm. Cuenta:", new JTextField());
                agregarCampo("Tipo Banco:", new JTextField());
                agregarCampo("Socio (Sí/No):", new JTextField());
                agregarCampo("Empleado De (Clave Acta):", new JTextField());
                agregarCampo("Salario:", new JTextField());
                break;
                
            case "AdmFondo":
                agregarCampo("Id. Acta:", new JTextField());
                agregarCampo("Nombre:", new JTextField());
                agregarCampo("Pago Depositado:", new JTextField());
                agregarCampo("Pago A Socios:", new JTextField());
                agregarCampo("Pago Cliente:", new JTextField());
                agregarCampo("N. ParaCorsa:", new JTextField());
                agregarCampo("Utilidad CORSA:", new JTextField());
                break;
                
            case "AsociadoCivil":
                agregarCampo("Asociado Civil:", new JTextField());
                agregarCampo("Folio Electrónico:", new JTextField());
                agregarCampo("Nombre:", new JTextField());
                agregarCampo("Núm. Socios:", new JTextField());
                agregarCampo("Tipo Sociedad:", new JTextField());
                agregarCampo("Dirección:", new JTextField());
                agregarCampo("Contratos Vigentes:", new JTextField());
                agregarCampo("Contratos No Vigentes:", new JTextField());
                break;
        }
        // Configuración de botones
        btnGuardar.setText("Guardar");
        btnCancelar.setText("Cancelar");
        
        btnGuardar.addActionListener(e -> guardarRegistro());
        btnCancelar.addActionListener(e -> dispose());
        
        // Reorganizar algo bello pal camello
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(new JScrollPane(panelCampos), BorderLayout.CENTER);
        
        panelBotones = new javax.swing.JPanel();
        panelBotones.add(btnGuardar);
        panelBotones.add(btnCancelar);
        getContentPane().add(panelBotones, BorderLayout.SOUTH);
    }
/**
     * Agrega un campo al panel de entrada, compuesto por una etiqueta y un componente (usualmente JTextField).
     * 
     * @param etiqueta El texto que describe el campo.
     * @param componente El componente de entrada asociado al campo.
     */
    private void agregarCampo(String etiqueta, JComponent componente) {
        panelCampos.add(new JLabel(etiqueta));
        panelCampos.add(componente);
        campos.put(etiqueta, componente);
    }
    /**
     * Método que valida y guarda el registro según el tipo seleccionado,
     * mostrando mensajes de éxito o error y actualizando la vista en el sistema principal.
     */
    private void guardarRegistro() {
         try {
        switch(tipoRegistro) {
            case "Cliente":
                guardarCliente();
                break;
            case "Empleado":
                guardarEmpleado();
                break;
            case "AdmFondo":
                guardarAdmFondo();
                break;
            case "AsociadoCivil":
                guardarAsociadoCivil();
                break;
        }
        JOptionPane.showMessageDialog(this, "Registro guardado con éxito");
        
        if (sistema != null) {
            sistema.mostrarTodosLosDatos(); //Actualizar datos
        }
        
        dispose();
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), 
                                   "Error", JOptionPane.ERROR_MESSAGE);
    }
    }
     /**
     * Obtiene los valores ingresados en los campos y guarda un nuevo Cliente.
     * 
     * @throws Exception si falta algún campo obligatorio o hay error en la conversión de datos.
     */
    private void guardarCliente() throws Exception {
        String claveActa = ((JTextField)campos.get("Clave Acta:")).getText().trim();
        String nombre = ((JTextField)campos.get("Nombre:")).getText().trim();
        int numTrabajadores = Integer.parseInt(((JTextField)campos.get("Núm. Trabajadores:")).getText().trim());
        String giro = ((JTextField)campos.get("Giro:")).getText().trim();
        int numSucursales = Integer.parseInt(((JTextField)campos.get("Núm. Sucursales:")).getText().trim());
        double montoInicial = Double.parseDouble(((JTextField)campos.get("Monto Inicial:")).getText().trim());
        String porcentajeGanancia = ((JTextField)campos.get("% Ganancia:")).getText().trim();
        String numCuenta = ((JTextField)campos.get("Núm. Cuenta:")).getText().trim();
        
        if (claveActa.isEmpty() || nombre.isEmpty()) {
            throw new Exception("Los campos obligatorios no pueden estar vacíos");
        }
        
        Cliente nuevo = new Cliente(claveActa, nombre, numTrabajadores, giro, 
                                 numSucursales, montoInicial, porcentajeGanancia, numCuenta);
        ClienteDAO.guardarCliente(nuevo);
    }
    /**
     * Obtiene los valores ingresados en los campos y guarda un nuevo Empleado.
     * 
     * @throws Exception si falta algún campo obligatorio o hay error en la conversión de datos.
     */
    private void guardarEmpleado() throws Exception {
        String curp = ((JTextField)campos.get("CURP:")).getText().trim();
        String nombre = ((JTextField)campos.get("Nombre:")).getText().trim();
        String apellidos = ((JTextField)campos.get("Apellidos:")).getText().trim();
        String correo = ((JTextField)campos.get("Correo:")).getText().trim();
        String telefono = ((JTextField)campos.get("Teléfono:")).getText().trim();
        String direccion = ((JTextField)campos.get("Dirección:")).getText().trim();
        String numCuenta = ((JTextField)campos.get("Núm. Cuenta:")).getText().trim();
        String tipoBanco = ((JTextField)campos.get("Tipo Banco:")).getText().trim();
        String socio = ((JTextField)campos.get("Socio (Sí/No):")).getText().trim();
        String empleadoDe = ((JTextField)campos.get("Empleado De (Clave Acta):")).getText().trim();
        double salario = Double.parseDouble(((JTextField)campos.get("Salario:")).getText().trim());
        
        if (curp.isEmpty() || nombre.isEmpty() || apellidos.isEmpty()) {
            throw new Exception("Los campos obligatorios no pueden estar vacíos");
        }
        
        Empleado nuevo = new Empleado(curp, nombre, apellidos, correo, telefono, 
                                    direccion, numCuenta, tipoBanco, socio, empleadoDe, salario);
        EmpleadoDAO.guardarEmpleado(nuevo);
    }
    private void guardarAdmFondo() throws Exception {
        String idActa = ((JTextField)campos.get("Id. Acta:")).getText().trim();
        String nombre = ((JTextField)campos.get("Nombre:")).getText().trim();
        double pagoDepositado = Double.parseDouble(((JTextField)campos.get("Pago Depositado:")).getText().trim());
        double pagoASocios = Double.parseDouble(((JTextField)campos.get("Pago A Socios:")).getText().trim());
        double pagoCliente = Double.parseDouble(((JTextField)campos.get("Pago Cliente:")).getText().trim());
        double nParaCorsa = Double.parseDouble(((JTextField)campos.get("N. ParaCorsa:")).getText().trim());
        double utilidadCorsa = Double.parseDouble(((JTextField)campos.get("Utilidad CORSA:")).getText().trim());
        
        if (idActa.isEmpty() || nombre.isEmpty()) {
            throw new Exception("Los campos obligatorios no pueden estar vacíos");
        }
        
        AdmFondo nuevo = new AdmFondo(idActa, nombre, pagoDepositado, pagoASocios, 
                                   pagoCliente, nParaCorsa, utilidadCorsa);
        AdmFondoDAO.guardarAdmFondo(nuevo);
    }
    private void guardarAsociadoCivil() throws Exception {
        String asociadoCivil = ((JTextField)campos.get("Asociado Civil:")).getText().trim();
        String folioElectronico = ((JTextField)campos.get("Folio Electrónico:")).getText().trim();
        String nombre = ((JTextField)campos.get("Nombre:")).getText().trim();
        int numSocios = Integer.parseInt(((JTextField)campos.get("Núm. Socios:")).getText().trim());
        String tipoSociedad = ((JTextField)campos.get("Tipo Sociedad:")).getText().trim();
        String direccion = ((JTextField)campos.get("Dirección:")).getText().trim();
        int contratosVigente = Integer.parseInt(((JTextField)campos.get("Contratos Vigentes:")).getText().trim());
        int contratosNoVigente = Integer.parseInt(((JTextField)campos.get("Contratos No Vigentes:")).getText().trim());
        
        if (asociadoCivil.isEmpty() || nombre.isEmpty()) {
            throw new Exception("Los campos obligatorios no pueden estar vacíos");
        }
        
        AsociadoCivil nuevo = new AsociadoCivil(asociadoCivil, folioElectronico, nombre, 
                                             numSocios, tipoSociedad, direccion, 
                                             contratosVigente, contratosNoVigente);
        AsociadoCivilDAO.guardarAsociado(nuevo);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelCampos = new javax.swing.JPanel();
        panelBotones = new javax.swing.JPanel();
        btnCancelar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(1, 19, 31));

        javax.swing.GroupLayout panelCamposLayout = new javax.swing.GroupLayout(panelCampos);
        panelCampos.setLayout(panelCamposLayout);
        panelCamposLayout.setHorizontalGroup(
            panelCamposLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 267, Short.MAX_VALUE)
        );
        panelCamposLayout.setVerticalGroup(
            panelCamposLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 249, Short.MAX_VALUE)
        );

        btnCancelar.setText("Guardar");

        btnGuardar.setText("Cancelar");

        javax.swing.GroupLayout panelBotonesLayout = new javax.swing.GroupLayout(panelBotones);
        panelBotones.setLayout(panelBotonesLayout);
        panelBotonesLayout.setHorizontalGroup(
            panelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBotonesLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(panelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnGuardar)
                    .addComponent(btnCancelar))
                .addContainerGap(114, Short.MAX_VALUE))
        );
        panelBotonesLayout.setVerticalGroup(
            panelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBotonesLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(btnCancelar)
                .addGap(18, 18, 18)
                .addComponent(btnGuardar)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelCampos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panelBotones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(panelCampos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(108, 108, 108)
                        .addComponent(panelBotones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(121, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JPanel panelBotones;
    private javax.swing.JPanel panelCampos;
    // End of variables declaration//GEN-END:variables
}
