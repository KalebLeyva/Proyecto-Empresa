/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unidad2;
/**
 * Representa un fondo de administración que contiene información financiera
 * relacionada con una acta específica.
 * 
 * Esta clase modela los montos involucrados en el manejo de fondos entre la
 * empresa, los socios y los clientes, así como la utilidad generada para Corsa.
 * 
 * @author MSI
 */
public class AdmFondo {
    public String idActa;
    public String nombre;
    public double pagoDepositado;
    public double pagoASocios;
    public double pagoCliente;
    public double nParaCorsa;
    public double utilidadCorsa;
    
    public AdmFondo(String idActa, String nombre, double pagoDepositado, 
                   double pagoASocios, double pagoCliente, 
                   double nParaCorsa, double utilidadCorsa) {
        this.idActa = idActa;
        this.nombre = nombre;
        this.pagoDepositado = pagoDepositado;
        this.pagoASocios = pagoASocios;
        this.pagoCliente = pagoCliente;
        this.nParaCorsa = nParaCorsa;
        this.utilidadCorsa = utilidadCorsa;
    }
}
