/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unidad2;
/**
 * Clase que representa un registro de Asociado Civil con sus atributos principales.
 * Contiene información básica como nombre, folio electrónico, número de socios,
 * tipo de sociedad, dirección y cantidad de contratos vigentes y no vigentes.
 * 
 * @author MSI
 */
public class AsociadoCivil {
    public String asociadoCivil;
    public String folioElectronico;
    public String nombre;
    public int numSocios;
    public String tipoSociedad;
    public String direccion;
    public int contratosVigente;
    public int contratosNoVigente;

    public AsociadoCivil(String asociadoCivil, String folioElectronico, String nombre, 
                       int numSocios, String tipoSociedad, String direccion,
                       int contratosVigente, int contratosNoVigente) {
        this.asociadoCivil = asociadoCivil;
        this.folioElectronico = folioElectronico;
        this.nombre = nombre;
        this.numSocios = numSocios;
        this.tipoSociedad = tipoSociedad;
        this.direccion = direccion;
        this.contratosVigente = contratosVigente;
        this.contratosNoVigente = contratosNoVigente;
    }
}
