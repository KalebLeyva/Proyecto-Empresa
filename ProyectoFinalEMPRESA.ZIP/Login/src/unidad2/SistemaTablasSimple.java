/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unidad2;
/**
 * Clase que representa el sistema principal de gestión con interfaz de pestañas.
 * Permite visualizar y gestionar clientes, empleados, administradores de fondos y asociados civiles.
 * 
 * @author Eduardo Yael Mendoza/Kaleb Daniel Leyva
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import unidad2.EmpleadoDAO;
import unidad2.Cliente;
import unidad2.Empleado;
import java.sql.SQLException;
import javax.swing.table.DefaultTableCellRenderer;
public class SistemaTablasSimple extends JFrame {
    private Usuario usuarioActual;
    private JTabbedPane tabbedPane;
    private ArrayList<Cliente> clientes;
    private ArrayList<Empleado> empleados;
    private ArrayList<AdmFondo> admFondos;
    private ArrayList<AsociadoCivil> asociadosCiviles;
private JTable tablaAsociadosCiviles;
private DefaultTableModel modelAsociadosCiviles;
JButton btnNuevoAsociadoCivil;
    private JTable tablaClientes;
    private JTable tablaEmpleados;
    private JTable tablaAdmFondos;
    private DefaultTableModel modelClientes;
    private DefaultTableModel modelEmpleados;
     private DefaultTableModel modelAdmFondos;
    private JButton btnAceptar;
    private JButton btnCancelar;
    private JButton btnSalir;
    JButton btnNuevoCliente;
    private JButton btnNuevoEmpleado;
    JButton btnNuevoAdmFondo;
    private JButton btnMostrarTodos;
    private String empresaSeleccionada = null;
    JButton registrarse;
    JButton btnEliminarUsuario;
    /**
     * Constructor principal que recibe un usuario para control de acceso.
     * 
     * @param usuario El usuario autenticado en el sistema
     */
    public SistemaTablasSimple(Usuario usuario) {
        getContentPane().setBackground(new Color(1, 19, 31));
        this.usuarioActual = usuario;
         try {
            initData();
            initUI();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar datos: " + ex.getMessage(), 
                                        "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    /**
     * Inicializa los datos cargándolos desde la base de datos.
     * Si no hay datos, crea algunos ejemplos.
     * 
     * @throws SQLException Si ocurre un error al acceder a la base de datos
     */
    private void initData() throws SQLException{
        // Carga de datos desde DAO
        clientes = ClienteDAO.cargarClientes();
        empleados = EmpleadoDAO.cargarEmpleados();
        admFondos = AdmFondoDAO.cargarAdmFondos();
        if (clientes.isEmpty()) {
            clientes.add(new Cliente("ACTA12345", "Grupo Industrial Jalisco", 5, "Manufactura", 
                                    3, 1000000.0, "15.0%", "1234567890"));
        }
        
        asociadosCiviles = AsociadoCivilDAO.cargarAsociados();
    // Datos de ejemplo para el usuario cuando las listan esten vacias
    if (asociadosCiviles.isEmpty()) {
        asociadosCiviles.add(new AsociadoCivil(
            "ASOC-001",         // asociado_civil
            "FOLIO-001",        // folio_electronico
            "Asociación Ejemplo S.A.", // nombre
            5,                  // num_socios
            "Sociedad Civil",   // tipo_sociedad
            "Av. Revolución 123", // direccion
            3,                  // contratos_vigente
            1                   // contratos_no_vigente
        ));
        
        asociadosCiviles.add(new AsociadoCivil(
            "ASOC-002",
            "FOLIO-002",
            "Cooperativa Libertad",
            12,
            "Cooperativa",
            "Calle Juárez 456",
            5,
            2
        ));
        AsociadoCivilDAO.guardarAsociados(asociadosCiviles);
    }
        
        if (empleados.isEmpty()) {
    empleados.add(new Empleado(
        "GARCJ90010IHICLRN03", 
        "Juan",               
        "García Ramírez",       
        "juan@email.com",       
        "5512345678",           
        "Calle Falsa 123",      
        "0011223344",           
        "BBVA",                 
        "Sí",                   
        "ACTA12345",            
        15000.50                
    ));
    
    empleados.add(new Empleado(
        "LOPEM880215HICLRP04", 
        "María", 
        "López Martínez",
        "maria@email.com",
        "5512345679",
        "Avenida Siempre Viva 742",
        "0011223345",
        "Santander",
        "Sí",
        "ACTA12345",
        16000.75
    ));
}
        if (admFondos.isEmpty()) {
            admFondos.add(new AdmFondo("ACTA12345", "Fondo Principal", 
                                       100000.0, 50000.0, 30000.0, 20000.0, 0.0));
        }
    }
    /**
     * Inicializa la interfaz de usuario con pestañas, tablas y botones.
     */
    private void initUI() {
        setTitle("Sistema de Gestión");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        // Configuración de componentes
        tabbedPane = new JTabbedPane();
        JPanel panelSuperior = new JPanel();
        // Botones para agregar nuevos registros
        // Configuración de eventos para botones
        btnNuevoCliente = new JButton("Nuevo Cliente");
        btnNuevoCliente.addActionListener(e -> {
       AgregarDatos agregarDatos = new AgregarDatos("Cliente", this);
       agregarDatos.setVisible(true);
   });
        
        btnNuevoEmpleado = new JButton("Nuevo Empleado");
        btnNuevoEmpleado.addActionListener(e -> {
       AgregarDatos agregarDatos = new AgregarDatos("Empleado", this);
       agregarDatos.setVisible(true);
   });
        
         btnNuevoAdmFondo = new JButton("Nuevo Adm. Fondo");
        btnNuevoAdmFondo.addActionListener(e -> {
       AgregarDatos agregarDatos = new AgregarDatos("AdmFondo", this);
       agregarDatos.setVisible(true);
   });
        
         btnNuevoAsociadoCivil = new JButton("Nuevo Asociado");
        btnNuevoAsociadoCivil.addActionListener(e -> {
       AgregarDatos agregarDatos = new AgregarDatos("AsociadoCivil", this);
       agregarDatos.setVisible(true);
   });
        panelSuperior.add(btnNuevoAsociadoCivil);
        
    registrarse= new JButton("Registrar Usuario");
    registrarse.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            VentanaUsuarios ventana= new VentanaUsuarios();
            ventana.setVisible(true);
        }
    } );    
    
   btnNuevoCliente.setVisible(false);
   btnNuevoEmpleado.setVisible(false);
   btnNuevoAdmFondo.setVisible(false);
   btnNuevoAsociadoCivil.setVisible(false);
   // Panel de búsqueda
   JPanel panelBusqueda = new JPanel(new GridBagLayout());
GridBagConstraints gbc = new GridBagConstraints();
gbc.insets = new Insets(5, 5, 5, 5); 
JLabel lblBuscarActa = new JLabel("Buscar por Clave Acta:");
gbc.gridx = 0;
gbc.gridy = 0;
gbc.anchor = GridBagConstraints.LINE_END;
panelBusqueda.add(lblBuscarActa, gbc);
JTextField txtBuscarActa = new JTextField(15);
gbc.gridx = 1;
gbc.gridy = 0;
gbc.anchor = GridBagConstraints.LINE_START;
panelBusqueda.add(txtBuscarActa, gbc);
JLabel lblBuscarNombre = new JLabel("Buscar por Nombre:");
gbc.gridx = 0;
gbc.gridy = 1;
gbc.anchor = GridBagConstraints.LINE_END;
panelBusqueda.add(lblBuscarNombre, gbc);
JTextField txtBuscarNombre = new JTextField(15);
gbc.gridx = 1;
gbc.gridy = 1;
gbc.anchor = GridBagConstraints.LINE_START;
panelBusqueda.add(txtBuscarNombre, gbc);
JButton btnBuscar = new JButton("Buscar");
gbc.gridx = 1;
gbc.gridy = 2;
gbc.anchor = GridBagConstraints.LINE_START;
panelBusqueda.add(btnBuscar, gbc);
panelSuperior.add(panelBusqueda);
    
    btnBuscar.addActionListener(e -> {
    String claveActa = txtBuscarActa.getText().trim();
    String nombre = txtBuscarNombre.getText().trim();
    
    if (!claveActa.isEmpty() && !nombre.isEmpty()) {
        // Buscar por ambos criterios
        buscarPorClaveActaYNombre(claveActa, nombre);
    } else if (!claveActa.isEmpty()) {
        buscarPorClaveActa(claveActa);
    } else if (!nombre.isEmpty()) {
        buscarPorNombre(nombre);
    } else {
        mostrarTodosLosDatos();
    }
});
        
        // Agregar nuevas pestañas        
        panelSuperior.add(btnNuevoCliente);
        panelSuperior.add(btnNuevoEmpleado);
        panelSuperior.add(btnNuevoAdmFondo);
        add(panelSuperior, BorderLayout.NORTH);
        // Creación de tablas
        // Pestaña de Clientes
        tablaClientes = createClientesTable();
        setupTableContextMenu(tablaClientes);
        tabbedPane.addTab("Clientes", new JScrollPane(tablaClientes));
        
        // Pestaña de Empleados
        tablaEmpleados = createEmpleadosTable();
        setupTableContextMenu(tablaEmpleados);
        tabbedPane.addTab("Empleados", new JScrollPane(tablaEmpleados));
        
        tablaAdmFondos = createAdmFondosTable();
        setupTableContextMenu(tablaAdmFondos);
        tabbedPane.addTab("Adm. Fondos", new JScrollPane(tablaAdmFondos));
        
        tablaAsociadosCiviles = createAsociadosCivilesTable();
    setupTableContextMenu(tablaAsociadosCiviles);
    tabbedPane.addTab("Asociados Civiles", new JScrollPane(tablaAsociadosCiviles));       
    
        add(tabbedPane, BorderLayout.CENTER);
        
        // Panel de botones
        JPanel panelBotones = new JPanel();
        
        btnAceptar = new JButton("Aceptar");
        btnAceptar.setEnabled(false);
        btnAceptar.addActionListener(e -> guardarCambios());
        
        btnCancelar = new JButton("Cancelar");
        btnCancelar.setEnabled(false);
        btnCancelar.addActionListener(e -> confirmarCancelar());
        
        btnSalir = new JButton("Salir");
        btnSalir.addActionListener(e -> System.exit(0));
        
        btnEliminarUsuario = new JButton("Eliminar Usuario");
    btnEliminarUsuario.addActionListener(e -> eliminarUsuario());
    btnEliminarUsuario.setEnabled(esUsuarioAdmin());
    panelSuperior.add(btnEliminarUsuario);
        
        panelBotones.add(btnAceptar);
        panelBotones.add(btnCancelar);
        panelBotones.add(btnSalir);
        panelBotones.add(registrarse);
        
        add(panelBotones, BorderLayout.SOUTH);
        
         // Agregar botón "Mostrar Todos"
        btnMostrarTodos = new JButton("Mostrar Todos");
        btnMostrarTodos.addActionListener(e -> mostrarTodosLosDatos());
        panelSuperior.add(btnMostrarTodos);
        
        tablaClientes.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (empresaSeleccionada != null && value.equals(empresaSeleccionada)) {
                c.setBackground(new Color(173, 216, 230)); // Azul claro
            } else {
                c.setBackground(table.getBackground());
            }
            
            return c;
        }
    });
    
    //Poibles indicaciones
    //tablaClientes.setToolTipText("Haz clic en una empresa para ver sus empleados");
    //tablaEmpleados.setToolTipText("Haz clic en una empresa para ver sus datos");
    //btnMostrarTodos.setToolTipText("Mostrar todos los registros sin filtros");

tabbedPane.addChangeListener(e -> {
        int selectedIndex = tabbedPane.getSelectedIndex();
        // Ocultar todos los botones
        btnNuevoCliente.setVisible(false);
    btnNuevoEmpleado.setVisible(false);
    btnNuevoAdmFondo.setVisible(false);
    btnNuevoAsociadoCivil.setVisible(false);
        //Mostrar el botón correspondiente según la pestaña seleccionada
        switch (selectedIndex) {
            case 0: // Clientes
                btnNuevoCliente.setVisible(true);
                break;
            case 1: // Empleados
                btnNuevoEmpleado.setVisible(true);
                break;
            case 2: // Adm. Fondos
                btnNuevoAdmFondo.setVisible(true);
                break;
            case 3: // Asociados Civiles
                btnNuevoAsociadoCivil.setVisible(true);
                break;
        }
    });
    }
    /**
 * Carga y muestra todos los datos disponibles desde la base de datos en las tablas correspondientes
 * del sistema. Esta función incluye la recarga de clientes, empleados, administradores de fondos y
 * asociados civiles. También reinicia la empresa seleccionada y desactiva el botón de "Mostrar todos".
 *
 * @throws SQLException si ocurre un error durante la carga de datos desde la base de datos.
 */
public void mostrarTodosLosDatos() {
    try {
        // Recargar todos los datos desde la base de datos usando los DAO correspondientes
        clientes = ClienteDAO.cargarClientes();              // Carga la lista de clientes
        empleados = EmpleadoDAO.cargarEmpleados();           // Carga la lista de empleados
        admFondos = AdmFondoDAO.cargarAdmFondos();           // Carga la lista de administradores de fondos
        asociadosCiviles = AsociadoCivilDAO.cargarAsociados(); // Carga la lista de asociados civiles

        // Actualizar las tablas visibles en la interfaz gráfica
        cargarDatosClientes();
        cargarDatosEmpleados();
        cargarDatosAdmFondos(); 
        cargarDatosAsociadosCiviles();

        // Limpiar la selección actual de empresa
        empresaSeleccionada = null;

        // Desactivar el botón de "Mostrar todos"
        btnMostrarTodos.setEnabled(false);

    } catch (SQLException ex) {
        // Mostrar un mensaje de error si ocurre un problema durante la carga de datos
        JOptionPane.showMessageDialog(this, 
            "Error al cargar datos: " + ex.getMessage(),
            "Error", JOptionPane.ERROR_MESSAGE);
    }
}
    /**
 * Configura un menú contextual (clic derecho) para una tabla dada.
 * Este menú permite editar o eliminar registros de forma dinámica.
 *
 * @param table la JTable a la cual se agregará el menú contextual.
 */
    private void setupTableContextMenu(JTable table) {
    JPopupMenu popupMenu = new JPopupMenu();
    JMenuItem editItem = new JMenuItem("Editar");
    
    editItem.addActionListener(e -> {
        // Cambiar el modelo para permitir edición
        if (table.getModel() instanceof DefaultTableModel) {
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.setRowCount(model.getRowCount()); 
            
            // Hacer todas las celdas editables temporalmente
            for (int i = 0; i < model.getRowCount(); i++) {
                for (int j = 0; j < model.getColumnCount(); j++) {
                    model.isCellEditable(i, j); // Esto activa la edicion
                }
            }
        }
        
        table.setEnabled(true);
        table.setCellSelectionEnabled(true);
        table.setRowSelectionAllowed(false);
        table.setColumnSelectionAllowed(false);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        btnAceptar.setEnabled(true);
        btnCancelar.setEnabled(true);
        
        // Permitir edicion
        if (table == tablaClientes) {
            modelClientes = new DefaultTableModel(
                new Object[]{"Clave Acta", "Nombre", "Trabajadores", "Giro", 
                           "Sucursales", "Monto Inicial", "% Ganancia", "Cuenta"}, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return true; // Ahora es editable
                }
            };
            cargarDatosClientes();
            tablaClientes.setModel(modelClientes);
        } else if (table == tablaEmpleados) {
            modelEmpleados = new DefaultTableModel(
                new Object[]{"CURP", "Nombre", "Apellidos", "Núm. Cuenta", 
                           "Socio", "Empleado De"}, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return true; // Ahora es editable
                }
            };
            cargarDatosEmpleados();
            tablaEmpleados.setModel(modelEmpleados);
        
        } else if (table == tablaAdmFondos) {
            modelAdmFondos = new DefaultTableModel(
                new Object[]{"Id. Acta", "Nombre", "Pago Depositado", "Pago A Socios", 
                           "Pago Cliente", "N. ParaCorsa", "Utilidad CORSA"}, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return true;
                }
            };
            cargarDatosAdmFondos();
            tablaAdmFondos.setModel(modelAdmFondos);
        }
    });
    
    popupMenu.add(editItem);
    
    table.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            if (SwingUtilities.isRightMouseButton(e)) {
                popupMenu.show(table, e.getX(), e.getY());
            }
        }
    });
     JMenuItem deleteItem = new JMenuItem("Eliminar");
    deleteItem.addActionListener(e -> eliminarFila(table));
    
    popupMenu.add(editItem);
    popupMenu.add(deleteItem);
    
    table.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            if (SwingUtilities.isRightMouseButton(e)) {
                popupMenu.show(table, e.getX(), e.getY());
            }
        }
    });
}
    /**
 * Elimina la fila seleccionada de la tabla y también de la base de datos.
 *
 * @param table la JTable desde la que se eliminará la fila seleccionada.
 */
    private void eliminarFila(JTable table) {
     int selectedRow = table.getSelectedRow();
    if (selectedRow >= 0) {
        int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Estás seguro de eliminar este registro?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION);
        
        if (confirmacion == JOptionPane.YES_OPTION) {
            try {
                if (table == tablaClientes) {
                    String claveActa = (String) modelClientes.getValueAt(selectedRow, 0);
                    ClienteDAO.eliminarCliente(claveActa);
                    modelClientes.removeRow(selectedRow);
                    clientes.remove(selectedRow);
                } else if (table == tablaEmpleados) {
                    String curp = (String) modelEmpleados.getValueAt(selectedRow, 0);
                    EmpleadoDAO.eliminarEmpleado(curp);
                    modelEmpleados.removeRow(selectedRow);
                    empleados.remove(selectedRow);
                }else if (table == tablaAdmFondos) {
            String idActa = (String) modelAdmFondos.getValueAt(selectedRow, 0);
            AdmFondoDAO.eliminarAdmFondo(idActa);
            modelAdmFondos.removeRow(selectedRow);
            admFondos.remove(selectedRow);
        }
                JOptionPane.showMessageDialog(this, "Registro eliminado correctamente", 
                                            "Información", JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Error al eliminar en MySQL:\n" + ex.getMessage(), 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    } else {
        JOptionPane.showMessageDialog(
            this,
            "Por favor selecciona una fila para eliminar",
            "Advertencia",
            JOptionPane.WARNING_MESSAGE);
    }
}
    /**
 * Guarda los cambios aplicados en la tabla visible, actualizando tanto
 * el modelo en memoria como la base de datos.
 */
    private void guardarCambios() {
         int respuesta = JOptionPane.showConfirmDialog(this, 
        "¿Estás seguro de aplicar los cambios?", 
        "Confirmar cambios", 
        JOptionPane.YES_NO_OPTION);
    
    if (respuesta == JOptionPane.YES_OPTION) {
        try {
            if (tablaClientes.isShowing()) {
                actualizarClientesDesdeTabla();
                ClienteDAO.guardarClientes(clientes);
            } else if (tablaEmpleados.isShowing()) {
                actualizarEmpleadosDesdeTabla();
                EmpleadoDAO.guardarEmpleados(empleados);
            } else if (tablaAdmFondos.isShowing()) {
                actualizarAdmFondosDesdeTabla();
                AdmFondoDAO.guardarAdmFondos(admFondos);
            }
            
            JOptionPane.showMessageDialog(this, "Cambios guardados correctamente", 
                                        "Información", JOptionPane.INFORMATION_MESSAGE);
            deshabilitarEdicion();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error al guardar en MySQL: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        // Si el usuario selecciona "No", no se hace nada
        JOptionPane.showMessageDialog(this, "Cambios no aplicados.", 
                                    "Información", JOptionPane.INFORMATION_MESSAGE);
    }
}
/**
 * Actualiza la lista de objetos {@code AdmFondo} en memoria a partir de los datos 
 * contenidos actualmente en la tabla de administradores de fondos.
 */
private void actualizarAdmFondosDesdeTabla() {
    admFondos.clear();
    for (int i = 0; i < modelAdmFondos.getRowCount(); i++) {
        admFondos.add(new AdmFondo(
            (String) modelAdmFondos.getValueAt(i, 0),
            (String) modelAdmFondos.getValueAt(i, 1),
            ((Number) modelAdmFondos.getValueAt(i, 2)).doubleValue(),
            ((Number) modelAdmFondos.getValueAt(i, 3)).doubleValue(),
            ((Number) modelAdmFondos.getValueAt(i, 4)).doubleValue(),
            ((Number) modelAdmFondos.getValueAt(i, 5)).doubleValue(),
            ((Number) modelAdmFondos.getValueAt(i, 6)).doubleValue()
        ));
    }
    }
    
    private void actualizarClientesDesdeTabla() {
        clientes.clear();
    for (int i = 0; i < modelClientes.getRowCount(); i++) {
        clientes.add(new Cliente(
            (String) modelClientes.getValueAt(i, 0),
            (String) modelClientes.getValueAt(i, 1),
            Integer.parseInt(modelClientes.getValueAt(i, 2).toString()),
            (String) modelClientes.getValueAt(i, 3),
            Integer.parseInt(modelClientes.getValueAt(i, 4).toString()),
            Double.parseDouble(modelClientes.getValueAt(i, 5).toString()),
            (String) modelClientes.getValueAt(i, 6),
            (String) modelClientes.getValueAt(i, 7)
        ));
    }
    }
    
    private void actualizarEmpleadosDesdeTabla() {
        empleados.clear();
    for (int i = 0; i < modelEmpleados.getRowCount(); i++) {
        empleados.add(new Empleado(
            (String) modelEmpleados.getValueAt(i, 0),  // CURP
            (String) modelEmpleados.getValueAt(i, 1),  // Nombre
            (String) modelEmpleados.getValueAt(i, 2),  // Apellidos
            (String) modelEmpleados.getValueAt(i, 3),  // Correo
            (String) modelEmpleados.getValueAt(i, 4),  // Teléfono
            (String) modelEmpleados.getValueAt(i, 5),  // Dirección
            (String) modelEmpleados.getValueAt(i, 6),  // Núm. Cuenta
            (String) modelEmpleados.getValueAt(i, 7),  // Tipo Banco
            (String) modelEmpleados.getValueAt(i, 8),  // Socio
            (String) modelEmpleados.getValueAt(i, 9),  // Empleado De
            ((Number) modelEmpleados.getValueAt(i, 10)).doubleValue()  // Salario
        ));
    }
    }
    /**
 * Muestra un cuadro de diálogo para confirmar la cancelación de los cambios.
 * Si el usuario acepta, se restauran los modelos de tabla no editables
 * y se recargan los datos actuales en pantalla.
 */
    private void confirmarCancelar() {
     int respuesta = JOptionPane.showConfirmDialog(this, 
        "¿Estás seguro de cancelar los cambios?", 
        "Confirmar cancelación", 
        JOptionPane.YES_NO_OPTION);
    
    if (respuesta == JOptionPane.YES_OPTION) {
        deshabilitarEdicion();
        // Recargar datos desde las listas actuales (no desde initData)
        if (tablaClientes.isShowing()) {
            cargarDatosClientes();
        } else {
            cargarDatosEmpleados();
        }
    }
    }
    /**
 * Restaura los modelos de tabla a su estado no editable, recarga los datos 
 * actuales desde las listas y desactiva la edición en las tablas y botones.
 */
    private void deshabilitarEdicion() {
    // Restaurar modelos no editables
    modelClientes = new DefaultTableModel(
        new Object[]{"Clave Acta", "Nombre", "Trabajadores", "Giro", 
                   "Sucursales", "Monto Inicial", "% Ganancia", "Cuenta"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    cargarDatosClientes();
    tablaClientes.setModel(modelClientes);
    
    modelEmpleados = new DefaultTableModel(
        new Object[]{"CURP", "Nombre", "Apellidos", "Núm. Cuenta", 
                   "Socio", "Empleado De"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    cargarDatosEmpleados();
    tablaEmpleados.setModel(modelEmpleados);
    
    modelAdmFondos = new DefaultTableModel(
            new Object[]{"Id. Acta", "Nombre", "Pago Depositado", "Pago A Socios", 
                       "Pago Cliente", "N. ParaCorsa", "Utilidad CORSA"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        cargarDatosAdmFondos();
        tablaAdmFondos.setModel(modelAdmFondos);
    
    tablaClientes.setEnabled(false);
    tablaEmpleados.setEnabled(false);
    btnAceptar.setEnabled(false);
    btnCancelar.setEnabled(false);
}
    /**
 * Crea e inicializa la tabla de clientes con un modelo no editable.
 * 
 * @return JTable con los datos de clientes.
 */
    private JTable createClientesTable() {
        String[] columnNames = {
            "Clave Acta", "Nombre", "Trabajadores", "Giro", 
            "Sucursales", "Monto Inicial", "% Ganancia", "Cuenta"
        };
        
        modelClientes = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Inicialmente no editable
            }
        };
        
        cargarDatosClientes();
        
        JTable table = new JTable(modelClientes);
        table.setEnabled(false);
        return table;
    }
    /**
 * Carga los datos actuales de los clientes en el modelo de la tabla.
 */
    private void cargarDatosClientes() {
        modelClientes.setRowCount(0);
        for (Cliente cliente : clientes) {
            Object[] row = {
                cliente.claveActa,
                cliente.nombre,
                cliente.numTrabajadores,
                cliente.giro,
                cliente.numSucursales,
                cliente.montoInicial,
                cliente.porcentajeGanancia,
                cliente.numCuenta
            };
            modelClientes.addRow(row);
        }
    }
    /**
 * Crea e inicializa la tabla de empleados con un modelo no editable.
 * 
 * @return JTable con los datos de empleados.
 */
    private JTable createEmpleadosTable() {
        String[] columnNames = {
            "CURP", "Nombre", "Apellidos", "Correo", "Teléfono",
        "Dirección", "Núm. Cuenta", "Tipo Banco", "Socio",  
        "Empleado De", "Salario"
        };
        
        modelEmpleados = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        cargarDatosEmpleados();
        
        JTable table = new JTable(modelEmpleados);
        table.setEnabled(false);
        return table;
    }
    /**
 * Carga los datos actuales de los empleados en el modelo de la tabla.
 */
    private void cargarDatosEmpleados() {
    modelEmpleados.setRowCount(0);
    for (Empleado empleado : empleados) {
        Object[] row = {
            empleado.curp,
            empleado.nombre,
            empleado.apellidos,
            empleado.correo,
            empleado.telefono,
            empleado.direccion,
            empleado.numCuenta,
            empleado.tipoBanco,
            empleado.socio,
            empleado.empleadoDe,
            empleado.salario
        };
        modelEmpleados.addRow(row);
    }
}
    /**
 * Método principal que inicia la aplicación y muestra la interfaz si el usuario está autenticado.
 * 
 * @param args Argumentos de línea de comandos (no utilizados).
 */
      public static void main(String[] args) {
    SistemaTablasSimple sistema = new SistemaTablasSimple(null);
    Usuario usuario = sistema.obtenerUsuarioActual();
    if (usuario != null) {
        SwingUtilities.invokeLater(() -> {
            SistemaTablasSimple ventana = new SistemaTablasSimple(usuario);
            ventana.setVisible(true);
        });
    } else {
        JOptionPane.showMessageDialog(null, "No hay usuario autenticado.", "Error", JOptionPane.ERROR_MESSAGE);
    }
  }
  /**
 * Crea e inicializa la tabla de administración de fondos con un modelo no editable.
 * 
 * @return JTable con los datos de fondos.
 */
    private JTable createAdmFondosTable() {
    String[] columnNames = {
        "Id. Acta", "Nombre", "Pago Depositado", "Pago A Socios", 
        "Pago Cliente", "N. ParaCorsa", "Utilidad CORSA"
    };
    
    modelAdmFondos = new DefaultTableModel(columnNames, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false; // Inicialmente no editable
        }
    };
    
    cargarDatosAdmFondos();
    
    JTable table = new JTable(modelAdmFondos);
    table.setEnabled(false);
    return table;
}
/**
 * Carga los datos de administración de fondos desde la base de datos en el modelo de la tabla.
 */
private void cargarDatosAdmFondos() {
    modelAdmFondos.setRowCount(0);
    try {
        admFondos = AdmFondoDAO.cargarAdmFondos();
        for (AdmFondo fondo : admFondos) {
            Object[] row = {
                fondo.idActa,
                fondo.nombre,
                fondo.pagoDepositado,
                fondo.pagoASocios,
                fondo.pagoCliente,
                fondo.nParaCorsa,
                fondo.utilidadCorsa
            };
            modelAdmFondos.addRow(row);
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, 
            "Error al cargar datos de Adm. Fondos: " + ex.getMessage(),
            "Error", JOptionPane.ERROR_MESSAGE);
    }
}
/**
 * Crea e inicializa la tabla de asociados civiles con un modelo editable.
 * 
 * @return JTable con los datos de asociados civiles.
 */
private JTable createAsociadosCivilesTable() {
    String[] columnNames = {
        "Asociado Civil", "Folio Electrónico", "Nombre",
        "Núm. Socios", "Tipo Sociedad", "Dirección",
        "Contratos Vigentes", "Contratos No Vigentes"
    };
    
    modelAsociadosCiviles = new DefaultTableModel(columnNames, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return true;
        }
    };
    
    cargarDatosAsociadosCiviles();
    JTable table = new JTable(modelAsociadosCiviles);
    table.setEnabled(false);
    return table;
}
/**
 * Carga los datos de los asociados civiles desde la base de datos en el modelo de la tabla.
 */
private void cargarDatosAsociadosCiviles() {
    try {
        asociadosCiviles = AsociadoCivilDAO.cargarAsociados();
        modelAsociadosCiviles.setRowCount(0);
        for (AsociadoCivil ac : asociadosCiviles) {
            modelAsociadosCiviles.addRow(new Object[]{
                ac.asociadoCivil,
                ac.folioElectronico,
                ac.nombre,
                ac.numSocios,
                ac.tipoSociedad,
                ac.direccion,
                ac.contratosVigente,
                ac.contratosNoVigente
            });
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error al cargar asociados: " + ex.getMessage(),
                                    "Error", JOptionPane.ERROR_MESSAGE);
    }
}
/**
 * Devuelve el componente JTabbedPane que contiene las pestañas de las distintas tablas.
 * 
 * @return JTabbedPane de la interfaz.
 */
public JTabbedPane getTabbedPane() {
    return tabbedPane;
}
/**
 * Permite al usuario eliminar otro usuario por su correo electrónico, previa confirmación.
 * Muestra mensajes de éxito o error según el resultado.
 */
private void eliminarUsuario() {
    String correo = JOptionPane.showInputDialog(this, "Ingrese el correo del usuario a eliminar:");
    
    if (correo != null && !correo.trim().isEmpty()) {
        int confirmacion = JOptionPane.showConfirmDialog(this, 
            "¿Estás seguro de eliminar el usuario con correo: " + correo + "?",
            "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        
        if (confirmacion == JOptionPane.YES_OPTION) {
            if (UsuarioDAO.borrarUsuario(correo)) {
                JOptionPane.showMessageDialog(this, "Usuario eliminado correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró un usuario con ese correo.", 
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    } else {
        JOptionPane.showMessageDialog(this, "Por favor ingrese un correo válido.", 
            "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}
/**
 * Verifica si el usuario actual tiene el rol de administrador.
 * 
 * @return true si el usuario actual es administrador; false en caso contrario.
 */
private boolean esUsuarioAdmin() {
    return usuarioActual != null && "admin".equals(usuarioActual.getRol());
}
/**
 * Obtiene el usuario actualmente autenticado desde la capa DAO.
 * 
 * @return Usuario actual autenticado o null si no hay ninguno.
 */
private Usuario obtenerUsuarioActual() {
    return UsuarioDAO.obtenerUsuarioActual();
}
/**
 * Busca registros por clave de acta en todas las tablas (clientes, empleados,
 * asociados civiles y administración de fondos) y actualiza las vistas con los resultados.
 * 
 * @param claveActa Clave del acta a buscar.
 */
private void buscarPorClaveActa(String claveActa) {
    try {
        // Buscar clientes
        ArrayList<Cliente> clientesFiltrados = ClienteDAO.buscarClientesPorClaveActa(claveActa);
        modelClientes.setRowCount(0);
        for (Cliente cliente : clientesFiltrados) {
            modelClientes.addRow(new Object[]{
                cliente.claveActa,
                cliente.nombre,
                cliente.numTrabajadores,
                cliente.giro,
                cliente.numSucursales,
                cliente.montoInicial,
                cliente.porcentajeGanancia,
                cliente.numCuenta
            });
        }
        // Buscar empleados
        ArrayList<Empleado> empleadosFiltrados = EmpleadoDAO.buscarEmpleadosPorClaveActa(claveActa);
        modelEmpleados.setRowCount(0);
        for (Empleado emp : empleadosFiltrados) {
            modelEmpleados.addRow(new Object[]{
                emp.curp,
                emp.nombre,
                emp.apellidos,
                emp.correo,
                emp.telefono,
                emp.direccion,
                emp.numCuenta,
                emp.tipoBanco,
                emp.socio,
                emp.empleadoDe,
                emp.salario
            });
        }
        // Buscar asociados civiles
        ArrayList<AsociadoCivil> asociadosFiltrados = AsociadoCivilDAO.buscarAsociadosPorClaveActa(claveActa);
        modelAsociadosCiviles.setRowCount(0);
        for (AsociadoCivil ac : asociadosFiltrados) {
            modelAsociadosCiviles.addRow(new Object[]{
                ac.asociadoCivil,
                ac.folioElectronico,
                ac.nombre,
                ac.numSocios,
                ac.tipoSociedad,
                ac.direccion,
                ac.contratosVigente,
                ac.contratosNoVigente
            });
        }
        // Buscar fondos de administración
        ArrayList<AdmFondo> fondosFiltrados = AdmFondoDAO.buscarAdmFondosPorClaveActa(claveActa);
        modelAdmFondos.setRowCount(0);
        for (AdmFondo fondo : fondosFiltrados) {
            modelAdmFondos.addRow(new Object[]{
                fondo.idActa,
                fondo.nombre,
                fondo.pagoDepositado,
                fondo.pagoASocios,
                fondo.pagoCliente,
                fondo.nParaCorsa,
                fondo.utilidadCorsa
            });
        }
         } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error al buscar: " + ex.getMessage(), 
                                    "Error", JOptionPane.ERROR_MESSAGE);
    }
}
/**
 * Realiza una búsqueda en todas las tablas (clientes, empleados, asociados civiles
 * y administración de fondos) utilizando el nombre como criterio de filtrado.
 * 
 * Este método actualiza los modelos de tabla con los resultados obtenidos desde
 * los respectivos DAOs. Si ocurre un error de base de datos, se muestra un cuadro de
 * diálogo informando del fallo.
 * 
 * @param nombre El nombre a buscar en los registros de cada entidad.
 */
private void buscarPorNombre(String nombre) {
    try {
        // Buscar clientes
        ArrayList<Cliente> clientesFiltrados = ClienteDAO.buscarClientesPorNombre(nombre);
        modelClientes.setRowCount(0);
        for (Cliente cliente : clientesFiltrados) {
            modelClientes.addRow(new Object[]{
                cliente.claveActa,
                cliente.nombre,
                cliente.numTrabajadores,
                cliente.giro,
                cliente.numSucursales,
                cliente.montoInicial,
                cliente.porcentajeGanancia,
                cliente.numCuenta
            });
        }
        
        // Buscar empleados
        ArrayList<Empleado> empleadosFiltrados = EmpleadoDAO.buscarEmpleadosPorNombre(nombre);
        modelEmpleados.setRowCount(0);
        for (Empleado emp : empleadosFiltrados) {
            modelEmpleados.addRow(new Object[]{
                emp.curp,
                emp.nombre,
                emp.apellidos,
                emp.correo,
                emp.telefono,
                emp.direccion,
                emp.numCuenta,
                emp.tipoBanco,
                emp.socio,
                emp.empleadoDe,
                emp.salario
            });
        }
        
        // Buscar asociados civiles
        ArrayList<AsociadoCivil> asociadosFiltrados = AsociadoCivilDAO.buscarAsociadosPorNombre(nombre);
        modelAsociadosCiviles.setRowCount(0);
        for (AsociadoCivil ac : asociadosFiltrados) {
            modelAsociadosCiviles.addRow(new Object[]{
                ac.asociadoCivil,
                ac.folioElectronico,
                ac.nombre,
                ac.numSocios,
                ac.tipoSociedad,
                ac.direccion,
                ac.contratosVigente,
                ac.contratosNoVigente
            });
        }
        
        // Buscar fondos de administración
        ArrayList<AdmFondo> fondosFiltrados = AdmFondoDAO.buscarAdmFondosPorNombre(nombre);
        modelAdmFondos.setRowCount(0);
        for (AdmFondo fondo : fondosFiltrados) {
            modelAdmFondos.addRow(new Object[]{
                fondo.idActa,
                fondo.nombre,
                fondo.pagoDepositado,
                fondo.pagoASocios,
                fondo.pagoCliente,
                fondo.nParaCorsa,
                fondo.utilidadCorsa
            });
        }
        
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error al buscar: " + ex.getMessage(), 
                                    "Error", JOptionPane.ERROR_MESSAGE);
    }
}
/**
 * Realiza una búsqueda en todas las tablas (clientes, empleados, asociados civiles
 * y administración de fondos) utilizando tanto la clave de acta como el nombre como 
 * criterios de filtrado combinados.
 * 
 * Este método actualiza los modelos de tabla con los resultados obtenidos desde
 * los respectivos DAOs. Si ocurre un error de base de datos, se muestra un cuadro de
 * diálogo informando del fallo.
 * 
 * @param claveActa La clave del acta con la cual se filtrarán los registros.
 * @param nombre El nombre a buscar adicionalmente en cada entidad.
 */
private void buscarPorClaveActaYNombre(String claveActa, String nombre) {
    try {
        // Buscar clientes
        ArrayList<Cliente> clientesFiltrados = ClienteDAO.buscarClientesPorClaveActaYNombre(claveActa, nombre);
        modelClientes.setRowCount(0);
        for (Cliente cliente : clientesFiltrados) {
            modelClientes.addRow(new Object[]{
                cliente.claveActa,
                cliente.nombre,
                cliente.numTrabajadores,
                cliente.giro,
                cliente.numSucursales,
                cliente.montoInicial,
                cliente.porcentajeGanancia,
                cliente.numCuenta
            });
        }
        
        // Buscar empleados
        ArrayList<Empleado> empleadosFiltrados = EmpleadoDAO.buscarEmpleadosPorClaveActaYNombre(claveActa, nombre);
        modelEmpleados.setRowCount(0);
        for (Empleado emp : empleadosFiltrados) {
            modelEmpleados.addRow(new Object[]{
                emp.curp,
                emp.nombre,
                emp.apellidos,
                emp.correo,
                emp.telefono,
                emp.direccion,
                emp.numCuenta,
                emp.tipoBanco,
                emp.socio,
                emp.empleadoDe,
                emp.salario
            });
        }
        
        // Buscar asociados civiles
        ArrayList<AsociadoCivil> asociadosFiltrados = AsociadoCivilDAO.buscarAsociadosPorClaveActaYNombre(claveActa, nombre);
        modelAsociadosCiviles.setRowCount(0);
        for (AsociadoCivil ac : asociadosFiltrados) {
            modelAsociadosCiviles.addRow(new Object[]{
                ac.asociadoCivil,
                ac.folioElectronico,
                ac.nombre,
                ac.numSocios,
                ac.tipoSociedad,
                ac.direccion,
                ac.contratosVigente,
                ac.contratosNoVigente
            });
        }
        
        // Buscar fondos de administración
        ArrayList<AdmFondo> fondosFiltrados = AdmFondoDAO.buscarAdmFondosPorClaveActaYNombre(claveActa, nombre);
        modelAdmFondos.setRowCount(0);
        for (AdmFondo fondo : fondosFiltrados) {
            modelAdmFondos.addRow(new Object[]{
                fondo.idActa,
                fondo.nombre,
                fondo.pagoDepositado,
                fondo.pagoASocios,
                fondo.pagoCliente,
                fondo.nParaCorsa,
                fondo.utilidadCorsa
            });
        }
        
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error al buscar: " + ex.getMessage(), 
                                    "Error", JOptionPane.ERROR_MESSAGE);
    }
}
}