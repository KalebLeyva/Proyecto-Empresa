/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unidad2;

import java.awt.Color;
import java.util.Date;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author kaleb
 */
public class EditValidacion {
    public static boolean validarCorreo(String correo, JTextField campoCorreo) {
        if (!correo.contains("@")) {
            campoCorreo.setBackground(new Color(255, 204, 204)); 
            return false;
        }

        if (!correo.matches(".*@(gmail\\.com|hotmail\\.com|outlook\\.com|yahoo\\.com|edu\\.mx|\\.mx|\\.com)$")) {
            campoCorreo.setBackground(new Color(255, 204, 204)); 
            return false;
        }

        if (correo.startsWith("@") || correo.indexOf("@") == correo.length() - 1) {
            campoCorreo.setBackground(new Color(255, 204, 204)); 
            return false;
        }
        campoCorreo.setBackground(Color.WHITE);
        return true;
    }
    
    public static boolean validarCampoTexto(String texto, JTextField label) {
        if (texto.isEmpty() || !texto.matches("[a-zA-Z]+")) {
            label.setBackground(new Color(255, 204, 204)); // Rojo claro si es inválido
            return false;
        } else {
            label.setBackground(Color.WHITE); // Blanco si es válido
            return true;
        }
    }

    public static boolean validarContraseña(String pass1, String pass2, JTextField label1, JTextField label2) {
       if (pass1.isEmpty() || pass1.length() < 8) {
            label1.setBackground(new Color(255, 204, 204));
            return false;
        }else {
            label1.setBackground(Color.WHITE);
        }
        
        if (!pass1.equals(pass2)) {
            label2.setBackground(new Color(255, 204, 204)); // Rojo si no coinciden
            return false;
        } else {
            label2.setBackground(Color.WHITE);
            return true;
        }
    }

    public static boolean validarSexo(boolean seleccionado) {
        if (!seleccionado) {
            JOptionPane.showMessageDialog(null, "Por favor seleccione un sexo", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    public static boolean validarFechaNacimiento(Date fecha) {
        if (fecha == null) {
            JOptionPane.showMessageDialog(null, "Por favor seleccione una fecha de nacimiento", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }
}
