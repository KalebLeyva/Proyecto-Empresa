/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unidad2;

/**
 *
 * @author MSI
 */
public class Cliente {
    public String claveActa;
    public String nombre;
    public int numTrabajadores;
    public String giro;
    public int numSucursales;
    public double montoInicial;
    public String porcentajeGanancia;
    public String numCuenta;
    
    public Cliente(String claveActa, String nombre, int numTrabajadores, 
                  String giro, int numSucursales, double montoInicial, 
                  String porcentajeGanancia, String numCuenta) {
        this.claveActa = claveActa;
        this.nombre = nombre;
        this.numTrabajadores = numTrabajadores;
        this.giro = giro;
        this.numSucursales = numSucursales;
        this.montoInicial = montoInicial;
        this.porcentajeGanancia = porcentajeGanancia;
        this.numCuenta = numCuenta;
    }
}
