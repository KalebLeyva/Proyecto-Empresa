/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unidad2;
/**
 * Clase DAO (Data Access Object) para manejar operaciones relacionadas con la tabla
 * {@code adm_fondos} en la base de datos. Proporciona métodos para cargar, guardar,
 * eliminar y buscar fondos de administración.
 * 
 * Utiliza conexiones proporcionadas por {@link ConexionMySQL}.
 * 
 * @author MSI
 */
import java.sql.*;
import java.util.ArrayList;

public class AdmFondoDAO {
    /**
     * Carga todos los fondos de administración desde la base de datos.
     * 
     * @return Lista de objetos {@link AdmFondo} cargados.
     * @throws SQLException Si ocurre un error al acceder a la base de datos.
     */
    public static ArrayList<AdmFondo> cargarAdmFondos() throws SQLException {
        ArrayList<AdmFondo> fondos = new ArrayList<>();
        String query = "SELECT * FROM adm_fondos";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                fondos.add(new AdmFondo(
                    rs.getString("id_acta"),
                    rs.getString("nombre"),
                    rs.getDouble("pago_depositado"),
                    rs.getDouble("pago_a_socios"),
                    rs.getDouble("pago_cliente"),
                    rs.getDouble("n_para_corsa"),
                    rs.getDouble("utilidad_corsa")
                ));
            }
        }
        return fondos;
    }
    /**
     * Guarda una lista de fondos en la base de datos, reemplazando los existentes.
     * 
     * Primero elimina todos los registros actuales en la tabla {@code adm_fondos}
     * y luego inserta los nuevos.
     * 
     * @param fondos Lista de fondos a guardar.
     * @throws SQLException Si ocurre un error durante la operación.
     */
    public static void guardarAdmFondos(ArrayList<AdmFondo> fondos) throws SQLException {
        String deleteQuery = "DELETE FROM adm_fondos";
        String insertQuery = "INSERT INTO adm_fondos (id_acta, nombre, pago_depositado, " +
                            "pago_a_socios, pago_cliente, n_para_corsa, utilidad_corsa) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             Statement stmt = conn.createStatement();
             PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {
            
            stmt.executeUpdate(deleteQuery);
            
            for (AdmFondo fondo : fondos) {
                pstmt.setString(1, fondo.idActa);
                pstmt.setString(2, fondo.nombre);
                pstmt.setDouble(3, fondo.pagoDepositado);
                pstmt.setDouble(4, fondo.pagoASocios);
                pstmt.setDouble(5, fondo.pagoCliente);
                pstmt.setDouble(6, fondo.nParaCorsa);
                pstmt.setDouble(7, fondo.utilidadCorsa);
                pstmt.executeUpdate();
            }
        }
    }
    /**
     * Elimina un fondo de administración de la base de datos según su clave de acta.
     * 
     * @param idActa Clave del acta del fondo a eliminar.
     * @throws SQLException Si ocurre un error durante la eliminación.
     */
    public static void eliminarAdmFondo(String idActa) throws SQLException {
        String query = "DELETE FROM adm_fondos WHERE id_acta = ?";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, idActa);
            pstmt.executeUpdate();
        }
    }
    /**
     * Verifica si se puede establecer una conexión válida con la base de datos de gestión.
     * 
     * @return {@code true} si la conexión es válida; {@code false} en caso contrario.
     */
    public static boolean probarConexion() {
        try (Connection conn = ConexionMySQL.getGestionConnection()) {
            return conn.isValid(2);
        } catch (SQLException ex) {
            return false;
        }
    }
    public static void guardarAdmFondo(AdmFondo fondo) throws SQLException {
    String insertQuery = "INSERT INTO adm_fondos (id_acta, nombre, pago_depositado, " +
                        "pago_a_socios, pago_cliente, n_para_corsa, utilidad_corsa) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    try (Connection conn = ConexionMySQL.getGestionConnection();
         PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {
        
        pstmt.setString(1, fondo.idActa);
        pstmt.setString(2, fondo.nombre);
        pstmt.setDouble(3, fondo.pagoDepositado);
        pstmt.setDouble(4, fondo.pagoASocios);
        pstmt.setDouble(5, fondo.pagoCliente);
        pstmt.setDouble(6, fondo.nParaCorsa);
        pstmt.setDouble(7, fondo.utilidadCorsa);
        
        pstmt.executeUpdate();
    }
}
    /**
     * Busca fondos de administración que coincidan exactamente con la clave del acta especificada.
     * 
     * @param claveActa Clave del acta a buscar.
     * @return Lista de fondos que coinciden con la clave del acta.
     * @throws SQLException Si ocurre un error en la consulta.
     */
    public static ArrayList<AdmFondo> buscarAdmFondosPorClaveActa(String claveActa) throws SQLException {
    ArrayList<AdmFondo> fondos = new ArrayList<>();
    String query = "SELECT * FROM adm_fondos WHERE id_acta = ?"; // Cambia esto según tu lógica
    try (Connection conn = ConexionMySQL.getGestionConnection();
         PreparedStatement pstmt = conn.prepareStatement(query)) {
        pstmt.setString(1, claveActa);
        ResultSet rs = pstmt.executeQuery();
        while (rs.next()) {
            fondos.add(new AdmFondo(
                rs.getString("id_acta"),
                rs.getString("nombre"),
                rs.getDouble("pago_depositado"),
                rs.getDouble("pago_a_socios"),
                rs.getDouble("pago_cliente"),
                rs.getDouble("n_para_corsa"),
                rs.getDouble("utilidad_corsa")
            ));
        }
    }
    return fondos;
}
    /**
     * Busca fondos de administración por coincidencia parcial del nombre.
     * 
     * @param nombre Nombre (o parte del nombre) a buscar.
     * @return Lista de fondos cuyo nombre coincide con el criterio.
     * @throws SQLException Si ocurre un error en la consulta.
     */
    public static ArrayList<AdmFondo> buscarAdmFondosPorNombre(String nombre) throws SQLException {
    ArrayList<AdmFondo> fondos = new ArrayList<>();
    String sql = "SELECT * FROM adm_fondos WHERE nombre LIKE ?";
    
    try (Connection conn = ConexionMySQL.getGestionConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        
        ps.setString(1, "%" + nombre + "%");
        
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                fondos.add(new AdmFondo(
                    rs.getString("id_acta"),
                    rs.getString("nombre"),
                    rs.getDouble("pago_depositado"),
                    rs.getDouble("pago_a_socios"),
                    rs.getDouble("pago_cliente"),
                    rs.getDouble("n_para_corsa"),
                    rs.getDouble("utilidad_corsa")
                ));
            }
        }
    }
    return fondos;
}
    /**
     * Busca fondos que coincidan parcialmente tanto con la clave del acta como con el nombre.
     * 
     * @param claveActa Clave del acta a buscar (con LIKE).
     * @param nombre Nombre del fondo a buscar (con LIKE).
     * @return Lista de fondos que cumplen con ambos criterios.
     * @throws SQLException Si ocurre un error durante la consulta.
     */
    public static ArrayList<AdmFondo> buscarAdmFondosPorClaveActaYNombre(String claveActa, String nombre) throws SQLException {
    ArrayList<AdmFondo> fondos = new ArrayList<>();
    String sql = "SELECT * FROM adm_fondos WHERE id_acta LIKE ? AND nombre LIKE ?";
    
    try (Connection conn = ConexionMySQL.getGestionConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        
        ps.setString(1, "%" + claveActa + "%");
        ps.setString(2, "%" + nombre + "%");
        
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                fondos.add(new AdmFondo(
                    rs.getString("id_acta"),
                    rs.getString("nombre"),
                    rs.getDouble("pago_depositado"),
                    rs.getDouble("pago_a_socios"),
                    rs.getDouble("pago_cliente"),
                    rs.getDouble("n_para_corsa"),
                    rs.getDouble("utilidad_corsa")
                ));
            }
        }
    }
    return fondos;
}
}