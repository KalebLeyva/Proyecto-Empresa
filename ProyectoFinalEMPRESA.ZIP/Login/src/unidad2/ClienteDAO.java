/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unidad2;

/**
 *
 * @author MSI
 */
import java.sql.*;
import java.util.ArrayList;

public class ClienteDAO {
    private static final String TABLA = "clientes";
    
    public static ArrayList<Cliente> cargarClientes() throws SQLException {
        ArrayList<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT * FROM " + TABLA;
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                clientes.add(new Cliente(
                    rs.getString("clave_acta"),
                    rs.getString("nombre"),
                    rs.getInt("num_trabajadores"),
                    rs.getString("giro"),
                    rs.getInt("num_sucursales"),
                    rs.getDouble("monto_inicial"),
                    rs.getString("porcentaje_ganancia"),
                    rs.getString("num_cuenta")
                ));
            }
        }
        return clientes;
    }
    
    public static ArrayList<Cliente> buscarClientesPorClaveActa(String claveActa) throws SQLException {
        ArrayList<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT * FROM " + TABLA + " WHERE clave_acta LIKE ?";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, "%" + claveActa + "%");
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                clientes.add(new Cliente(
                    rs.getString("clave_acta"),
                    rs.getString("nombre"),
                    rs.getInt("num_trabajadores"),
                    rs.getString("giro"),
                    rs.getInt("num_sucursales"),
                    rs.getDouble("monto_inicial"),
                    rs.getString("porcentaje_ganancia"),
                    rs.getString("num_cuenta")
                ));
            }
        }
        return clientes;
    }
    
    public static void guardarCliente(Cliente cliente) throws SQLException {
        String sql = "INSERT INTO " + TABLA + " (clave_acta, nombre, num_trabajadores, giro, " +
                    "num_sucursales, monto_inicial, porcentaje_ganancia, num_cuenta) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, cliente.claveActa);
            pstmt.setString(2, cliente.nombre);
            pstmt.setInt(3, cliente.numTrabajadores);
            pstmt.setString(4, cliente.giro);
            pstmt.setInt(5, cliente.numSucursales);
            pstmt.setDouble(6, cliente.montoInicial);
            pstmt.setString(7, cliente.porcentajeGanancia);
            pstmt.setString(8, cliente.numCuenta);
            
            pstmt.executeUpdate();
        }
    }
    
    public static void guardarClientes(ArrayList<Cliente> clientes) throws SQLException {
        String deleteSql = "DELETE FROM " + TABLA;
        String insertSql = "INSERT INTO " + TABLA + " (clave_acta, nombre, num_trabajadores, giro, " +
                         "num_sucursales, monto_inicial, porcentaje_ganancia, num_cuenta) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             Statement stmt = conn.createStatement();
             PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
            
            stmt.executeUpdate(deleteSql);
            
            for (Cliente cliente : clientes) {
                pstmt.setString(1, cliente.claveActa);
                pstmt.setString(2, cliente.nombre);
                pstmt.setInt(3, cliente.numTrabajadores);
                pstmt.setString(4, cliente.giro);
                pstmt.setInt(5, cliente.numSucursales);
                pstmt.setDouble(6, cliente.montoInicial);
                pstmt.setString(7, cliente.porcentajeGanancia);
                pstmt.setString(8, cliente.numCuenta);
                pstmt.addBatch();
            }
            pstmt.executeBatch();
        }
    }
    
    public static void eliminarCliente(String claveActa) throws SQLException {
        String sql = "DELETE FROM clientes WHERE clave_acta = ?";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, claveActa);
            pstmt.executeUpdate();
        }
    }
    
    public static boolean existeCliente(String claveActa) throws SQLException {
        String sql = "SELECT COUNT(*) FROM " + TABLA + " WHERE clave_acta = ?";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, claveActa);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }
    public static ArrayList<Cliente> buscarClientesPorNombre(String nombre) throws SQLException {
    ArrayList<Cliente> clientes = new ArrayList<>();
    String sql = "SELECT * FROM " + TABLA + " WHERE nombre LIKE ?";
    
    try (Connection conn = ConexionMySQL.getGestionConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        
        ps.setString(1, "%" + nombre + "%");
        
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                clientes.add(new Cliente(
                    rs.getString("clave_acta"),
                    rs.getString("nombre"),
                    rs.getInt("num_trabajadores"),
                    rs.getString("giro"),
                    rs.getInt("num_sucursales"),
                    rs.getDouble("monto_inicial"),
                    rs.getString("porcentaje_ganancia"),
                    rs.getString("num_cuenta")
                ));
            }
        }
    }
    return clientes;
}
    public static ArrayList<Cliente> buscarClientesPorClaveActaYNombre(String claveActa, String nombre) throws SQLException {
    ArrayList<Cliente> clientes = new ArrayList<>();
    String sql = "SELECT * FROM " + TABLA + " WHERE clave_acta LIKE ? AND nombre LIKE ?";
    
    try (Connection conn = ConexionMySQL.getGestionConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        
        ps.setString(1, "%" + claveActa + "%");
        ps.setString(2, "%" + nombre + "%");
        
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                clientes.add(new Cliente(
                    rs.getString("clave_acta"),
                    rs.getString("nombre"),
                    rs.getInt("num_trabajadores"),
                    rs.getString("giro"),
                    rs.getInt("num_sucursales"),
                    rs.getDouble("monto_inicial"),
                    rs.getString("porcentaje_ganancia"),
                    rs.getString("num_cuenta")
                ));
            }
        }
    }
    return clientes;
}
}