/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unidad2;
/**
 * Representa un empleado con sus datos personales, bancarios y laborales.
 * 
 * Contiene información como CURP, nombre completo, contacto, detalles bancarios,
 * asociación y salario.
 * 
 * @author MSI
 */
public class Empleado {
    public String curp;
    public String nombre;
    public String apellidos;
    public String correo;
    public String telefono;
    public String direccion;
    public String numCuenta;
    public String tipoBanco;
    public String socio;
    public String empleadoDe;
    public double salario;

    public Empleado(String curp, String nombre, String apellidos, String correo, 
               String telefono, String direccion, String numCuenta, 
               String tipoBanco, String socio, String empleadoDe, double salario) {
    this.curp = curp;
    this.nombre = nombre;
    this.apellidos = apellidos;
    this.correo = correo;
    this.telefono = telefono;
    this.direccion = direccion;
    this.numCuenta = numCuenta;
    this.tipoBanco = tipoBanco;
    this.socio = socio;
    this.empleadoDe = empleadoDe;
    this.salario = salario;
}
}
