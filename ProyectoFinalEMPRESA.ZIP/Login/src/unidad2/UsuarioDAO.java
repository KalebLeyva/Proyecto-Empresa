/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unidad2;
/**
 * Clase DAO (Data Access Object) para manejar operaciones CRUD y de autenticación
 * relacionadas con la entidad Usuario en la base de datos.
 * Incluye métodos para insertar usuarios, autenticarlos, buscar, actualizar contraseña,
 * obtener listas y eliminar usuarios.
 * También maneja el hash de contraseñas usando BCrypt.
 * 
 * @author Eduardo Yael/ Kaleb Daniel
 */
import java.util.List;
import java.sql.*;
import java.util.ArrayList;
import org.mindrot.jbcrypt.BCrypt;

public class UsuarioDAO {
    /**
     * Genera un hash seguro para una contraseña utilizando BCrypt.
     * 
     * @param password La contraseña en texto plano a hashear.
     * @return El hash resultante de la contraseña.
     */
    static String hashPassword(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt(10));
    }
    /**
     * Verifica si una contraseña en texto plano corresponde a un hash dado.
     * 
     * @param password La contraseña en texto plano.
     * @param hash El hash almacenado para comparar.
     * @return true si la contraseña corresponde al hash, false en caso contrario.
     */
    public static boolean verificarPassword(String password, String hash) {
        try {
            return BCrypt.checkpw(password, hash);
        } catch (Exception e) {
            System.err.println("Error al verificar contraseña: " + e.getMessage());
            return false;
        }
    }
     /**
     * Inserta un nuevo usuario en la base de datos con todos sus datos y rol asignado.
     * La contraseña se almacena como hash.
     * 
     * @param usuario Objeto Usuario con la información a insertar.
     * @throws SQLException Si ocurre un error en la base de datos.
     */
    public static void insertarUsuario(Usuario usuario) throws SQLException {
        String sql = "INSERT INTO usuarios (nombre, apellidoP, apellidoM, correo, contraseña, fecha_nacimiento, sexo, rol) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = ConexionMySQL.getLoginConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, usuario.getNombre());
            stmt.setString(2, usuario.getApellidoP());
            stmt.setString(3, usuario.getApellidoM());
            stmt.setString(4, usuario.getCorreo());
            stmt.setString(5, hashPassword(usuario.getContraseña())); // Encriptar
            stmt.setDate(6, new java.sql.Date(usuario.getFechaNacimiento().getTime()));
            stmt.setBoolean(7, usuario.isSexo());
            stmt.setString(8, usuario.getRol());
            
            stmt.executeUpdate();
        }
    }
    /**
     * Autentica a un usuario verificando su correo y contraseña.
     * Si la autenticación es exitosa, retorna el objeto Usuario y lo establece como usuario actual.
     * 
     * @param correo Correo electrónico del usuario.
     * @param password Contraseña en texto plano para verificar.
     * @return Usuario autenticado o null si falla la autenticación.
     * @throws SQLException Si ocurre un error en la base de datos.
     */
    public static Usuario autenticar(String correo, String password) throws SQLException {
        String sql = "SELECT * FROM usuarios WHERE correo = ?";
        Usuario usuario = null;
        
        try (Connection conn = ConexionMySQL.getLoginConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, correo);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                String hash = rs.getString("contraseña");
                if (verificarPassword(password, hash)) {
                    usuario = new Usuario(
                        rs.getString("nombre"),
                        rs.getString("apellidoP"),
                        rs.getString("apellidoM"),
                        rs.getString("correo"),
                        hash, // Guardamos el hash, no la contraseña en texto plano
                        rs.getDate("fecha_nacimiento"),
                        rs.getBoolean("sexo"),
                        rs.getString("rol"));
                     setUsuarioActual(usuario);
                }
            }
        }
        return usuario;
    }
    /**
     * Busca un usuario en la base de datos por su correo electrónico.
     * 
     * @param correo Correo electrónico del usuario a buscar.
     * @return Objeto Usuario si se encuentra, null si no existe.
     * @throws SQLException Si ocurre un error en la base de datos.
     */
    public static Usuario buscarPorCorreo(String correo) throws SQLException {
        String sql = "SELECT * FROM usuarios WHERE correo = ?";
        Usuario usuario = null;
        
        try (Connection conn = ConexionMySQL.getLoginConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, correo);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                usuario = new Usuario(
    rs.getString("nombre"),
    rs.getString("apellidoP"),
    rs.getString("apellidoM"),
    rs.getString("correo"),
    rs.getString("contraseña"),
    rs.getDate("fecha_nacimiento"),
    rs.getBoolean("sexo"),
    rs.getString("rol"));
            }
        }
        return usuario;
    }
    /**
     * Actualiza la contraseña de un usuario especificado por correo.
     * La nueva contraseña se almacena como hash.
     * 
     * @param correo Correo electrónico del usuario cuya contraseña será actualizada.
     * @param nuevaContraseña Nueva contraseña en texto plano.
     * @return true si la actualización fue exitosa, false si no.
     */
    public static boolean actualizarContraseña(String correo, String nuevaContraseña) {
        String sql = "UPDATE usuarios SET contraseña = ? WHERE correo = ?";
        
        try (Connection conn = ConexionMySQL.getLoginConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, hashPassword(nuevaContraseña)); // Encriptar nueva contraseña
            stmt.setString(2, correo);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al actualizar contraseña: " + ex.getMessage());
            return false;
        }
    }
    /**
     * Obtiene una lista con todos los usuarios registrados en la base de datos.
     * 
     * @return Lista de objetos Usuario.
     * @throws SQLException Si ocurre un error en la base de datos.
     */
    public static List<Usuario> obtenerUsuarios() throws SQLException {
    List<Usuario> usuarios = new ArrayList<>();
    String sql = "SELECT * FROM sistema_login.usuarios"; // Asegúrate de especificar la base de datos

    try (Connection conn = ConexionMySQL.getLoginConnection();
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {
        
        while (rs.next()) {
            Usuario usuario = new Usuario(
                rs.getString("nombre"),
                rs.getString("apellidoP"),
                rs.getString("apellidoM"),
                rs.getString("correo"),
                rs.getString("contraseña"),
                rs.getDate("fecha_nacimiento"),
                rs.getBoolean("sexo"),
                rs.getString("rol")); // Asegúrate de que la columna 'rol' exista en la tabla
            usuarios.add(usuario);
        }
    }
    return usuarios;
}
    /**
     * Elimina un usuario de la base de datos dado su correo electrónico.
     * 
     * @param correo Correo electrónico del usuario a eliminar.
     * @return true si se eliminó al usuario, false si no.
     */
    public static boolean borrarUsuario(String correo) {
    String sql = "DELETE FROM usuarios WHERE correo = ?";
    
    try (Connection conn = ConexionMySQL.getLoginConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, correo);
        return stmt.executeUpdate() > 0; // Retorna true si se eliminó al menos un registro
    } catch (SQLException ex) {
        System.err.println("Error al borrar usuario: " + ex.getMessage());
        return false;
    }
}
private static Usuario usuarioActual; // Variable estática para almacenar el usuario actual
    // Método para establecer el usuario actual
    public static void setUsuarioActual(Usuario usuario) {
        usuarioActual = usuario;
    }
    // Método para obtener el usuario actual
    public static Usuario obtenerUsuarioActual() {
        return usuarioActual;
    }

}