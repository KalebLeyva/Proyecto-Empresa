/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package unidad2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
/**
 * Clase que representa la ventana de inicio de sesión para el sistema de impuestos.
 * Permite a los usuarios ingresar con su correo electrónico y contraseña.
 * 
 * @author Eduardo Yael Mendoza/Kaleb Daniel Leyva
 */
public class LoginImpuestos extends javax.swing.JFrame {    
    /**
     * Constructor que recibe una lista de usuarios.
     * 
     * @param listaUsuarios ArrayList de usuarios para autenticación
     */
    public LoginImpuestos(ArrayList<Usuario> listaUsuarios) {
    initComponents(); // Inicializa la ventana
     this.setUndecorated(false);
     
}
    /**
     * Constructor por defecto que inicializa la ventana de login.
     */
    public LoginImpuestos() {
        this.setUndecorated(true);
        initComponents();
         // Configuración básica de la ventana
        setLocationRelativeTo(null);
    
    // Configuración de cierre
    setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
    // Configuración visual de componentes
    btnSalir.setBackground(Color.RED);
    btnSalir.setForeground(Color.WHITE);
    btnIngresar.setBackground(new Color(0, 0, 128));
    btnIngresar.setForeground(Color.WHITE);
    btnLimpiar.setBackground(new Color(0, 0, 128));
    btnLimpiar.setForeground(Color.WHITE);
    btnRecuperarContraseña.setForeground(Color.BLUE);
    new ArrayList<>();
    }

    /**
     * Método que se ejecuta al hacer clic en el botón de recuperar contraseña.
     * Abre la ventana de recuperación de contraseña y cierra la actual.
     * 
     * @param evt Evento de acción
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnRecuperarContraseña = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        lblCorreo = new customtextfield.CustomTextField();
        btnIngresar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnVer = new javax.swing.JButton();
        lblContraseña = new javax.swing.JPasswordField();
        jLabel2 = new javax.swing.JLabel();
        lblErrorContraseña = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        lblojo = new javax.swing.JLabel();
        lblErrorCorreo = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnRecuperarContraseña.setText("¿Olvidaste tu contraseña?");
        btnRecuperarContraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecuperarContraseñaActionPerformed(evt);
            }
        });
        jPanel1.add(btnRecuperarContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 20));

        btnSalir.setText("X");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        jPanel1.add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 10, -1, -1));

        jPanel2.setBackground(new java.awt.Color(1, 19, 31));

        lblCorreo.setBackground(new java.awt.Color(1, 19, 31));
        lblCorreo.setForeground(new java.awt.Color(54, 196, 146));
        lblCorreo.setBorderColor(new java.awt.Color(54, 196, 146));
        lblCorreo.setFocusColor(new java.awt.Color(54, 196, 146));
        lblCorreo.setFocusable(false);
        lblCorreo.setLabelText("Correo Electronico");
        lblCorreo.setMaxLength(40);
        lblCorreo.setTextColor(java.awt.Color.black);

        btnIngresar.setBackground(new java.awt.Color(54, 196, 146));
        btnIngresar.setText("Ingresar");
        btnIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarActionPerformed(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnVer.setBackground(new java.awt.Color(54, 196, 146));
        btnVer.setText("👁");
        btnVer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerActionPerformed(evt);
            }
        });

        jLabel2.setForeground(new java.awt.Color(54, 196, 146));
        jLabel2.setText("Contraseña:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 674, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 150, Short.MAX_VALUE)
        );

        lblojo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblojoMouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/LogoEmpresaREDIMENSIONADO.png"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblErrorContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(86, 86, 86)
                .addComponent(btnLimpiar)
                .addGap(534, 534, 534))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(lblErrorCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(5, 5, 5))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(lblojo, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblCorreo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(btnIngresar, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(lblContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnVer, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(129, 129, 129)
                        .addComponent(jLabel3)
                        .addGap(245, 245, 245)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 199, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2)
                        .addGap(2, 2, 2))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblErrorCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
                        .addComponent(btnLimpiar))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblojo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnVer, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblErrorContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnIngresar))))
                .addGap(9, 9, 9))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 110, 610, 390));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondodepantalla.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 880, 620));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRecuperarContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecuperarContraseñaActionPerformed
 RecuperarContraseña nuevo = new RecuperarContraseña();
        nuevo.setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_btnRecuperarContraseñaActionPerformed
/**
     * Método que alterna entre mostrar y ocultar la contraseña.
     * 
     * @param evt Evento de acción
     */
    private void btnVerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerActionPerformed
 if (mostrar) {
            lblContraseña.setEchoChar('*');
            btnVer.setText("👁");
        } else {
            lblContraseña.setEchoChar((char) 0);
            btnVer.setText("🔒");
        }
        mostrar = !mostrar;        // TODO add your handling code here:
    }//GEN-LAST:event_btnVerActionPerformed
/**
     * Método que limpia los campos de correo y contraseña.
     * 
     * @param evt Evento de acción
     */
    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        lblCorreo.setText("");
        lblContraseña.setText("");        // TODO add your handling code here:
    }//GEN-LAST:event_btnLimpiarActionPerformed
/**
     * Método que valida los datos de inicio de sesión.
     * Verifica el formato del correo electrónico antes de validar la contraseña.
     * 
     * @param evt Evento de acción
     */
    private void btnIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarActionPerformed
        String correo;
        correo=lblCorreo.getText().toLowerCase();
        String contraseñaIngresada = new String(lblContraseña.getPassword());
        LibreriaValidacion validacion;
        validacion=new LibreriaValidacion();
        if(!correo.contains("@")){
            lblErrorCorreo.setText(validacion.ErrorArroba(this));
            lblErrorCorreo.setForeground(Color.RED);
            return;
        }
        else if(!(correo.contains(".com")||correo.contains(".edu")||correo.contains(".mx"))){
            lblErrorCorreo.setText(validacion.ErrorTerminaciones(this));
            lblErrorCorreo.setForeground(Color.RED);
            return;
        }
        else if(!(correo.contains("gmail")||correo.contains("outlook")||correo.contains("hotmail")||correo.contains("itoaxaca")||correo.contains("yahoo"))){
            lblErrorCorreo.setText(validacion.ErrorDireccion(this));
            lblErrorCorreo.setForeground(Color.RED);
            return;
        }
        lblErrorCorreo.setText("");
        ValidarContraseña();        // TODO add your handling code here:
    }//GEN-LAST:event_btnIngresarActionPerformed
/**
     * Método que confirma la salida del sistema.
     * 
     * @param evt Evento de acción
     */
    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        int confirm = JOptionPane.showConfirmDialog(
                null, 
                "¿Estás seguro de que quieres salir?", 
                "Confirmar salida", 
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
            );
            if (confirm == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
    }//GEN-LAST:event_btnSalirActionPerformed
/**
     * Método para manejar el evento de clic en el icono de ojo.
     * 
     * @param evt Evento del mouse
     */
    private void lblojoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblojoMouseClicked

    }//GEN-LAST:event_lblojoMouseClicked
/**
     * Método que valida la contraseña ingresada contra la base de datos.
     * Redirige a diferentes ventanas según el rol del usuario.
     */    
    public void ValidarContraseña(){
        String correoIngresado = lblCorreo.getText().toLowerCase();
        String contraseñaIngresada = new String(lblContraseña.getPassword());
        if (correoIngresado.isEmpty()) {
            lblErrorContraseña.setText("El correo no puede estar vacío");
            lblErrorContraseña.setForeground(Color.RED);
            return;
        }
        if (contraseñaIngresada.isEmpty()) {
            lblErrorContraseña.setText("La contraseña no puede estar vacía");
            lblErrorContraseña.setForeground(Color.RED);
            return;
        }
        if(contraseñaIngresada.length()<8){
            lblErrorContraseña.setText("La contraseña debe ser de 8 caracteres");
            lblErrorContraseña.setForeground(Color.RED);
        }
        try {
    // Consultar la base de datos para el usuario
    Usuario usuario = UsuarioDAO.buscarPorCorreo(correoIngresado);
    
    if (usuario != null) {
        // Verificar la contraseña usando BCrypt
        if (UsuarioDAO.verificarPassword(contraseñaIngresada, usuario.getContraseña())) {
            UsuarioDAO.setUsuarioActual(usuario);
            if ("admin".equals(usuario.getRol())) {
                // Redirigir a ventana de administrador
                SistemaTablasSimple sistema = new SistemaTablasSimple(usuario);
                sistema.setVisible(true);
                sistema.btnEliminarUsuario.setEnabled(true);
            } else {
                // Redirigir a ventana de cliente normal
                VentanaCliente cliente = new VentanaCliente(usuario);
                cliente.setVisible(true);
            }
            this.dispose();
        } else {
            // Contraseña incorrecta
            lblErrorContraseña.setText("Contraseña incorrecta");
            lblErrorContraseña.setForeground(Color.RED);
        }
    } else {
        // Usuario no encontrado
        lblErrorContraseña.setText("Correo electrónico no registrado");
        lblErrorContraseña.setForeground(Color.RED);
    }
} catch (SQLException ex) {
    // Error de base de datos
    lblErrorContraseña.setText("Error al consultar la base de datos");
    lblErrorContraseña.setForeground(Color.RED);
    System.err.println("Error de BD: " + ex.getMessage());
    ex.printStackTrace();
}
    }
     /**
     * Método que valida un usuario contra la base de datos.
     * 
     * @param correo Correo electrónico del usuario
     * @param contraseña Contraseña del usuario
     * @return true si las credenciales son válidas, false en caso contrario
     */
    public boolean validarUsuario(String correo, String contraseña) {
    try {
        Usuario usuario = UsuarioDAO.buscarPorCorreo(correo);
        
        if (usuario == null) {
            System.out.println("Usuario no encontrado en BD");
            return false;
        }
        
        System.out.println("Contraseña en BD: " + usuario.getContraseña());
        System.out.println("Contraseña ingresada: " + contraseña);
        
        return contraseña != null && contraseña.equals(usuario.getContraseña());
        
    } catch (SQLException ex) {
        System.err.println("[ERROR] Fallo al acceder a la BD: " + ex.getMessage());
        ex.printStackTrace();
        return false;
    }
    
}   
    private boolean mostrar=false;
    /**
     * Método principal para ejecutar la aplicación.
     * 
     * @param args Argumentos de línea de comandos
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginImpuestos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginImpuestos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginImpuestos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginImpuestos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
LoginImpuestos login = new LoginImpuestos();
    login.setVisible(true); // Mostrar la ventana
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginImpuestos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnIngresar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnRecuperarContraseña;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnVer;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPasswordField lblContraseña;
    private customtextfield.CustomTextField lblCorreo;
    private javax.swing.JLabel lblErrorContraseña;
    private javax.swing.JLabel lblErrorCorreo;
    private javax.swing.JLabel lblojo;
    // End of variables declaration//GEN-END:variables
}
