/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unidad2;

import javax.swing.JTabbedPane;
/**
 * Clase que representa la ventana principal para usuarios con rol de cliente.
 * Hereda de {@link SistemaTablasSimple} y personaliza la interfaz para 
 * restringir funcionalidades que no deben estar disponibles para clientes.
 * 
 * Deshabilita botones relacionados con la creación o eliminación de usuarios
 * y oculta pestañas del tabbed pane que no son accesibles para este rol.
 * 
 * @author Eduardo/Kaleb Daniel
 */
public class VentanaCliente extends SistemaTablasSimple {
    /**
     * Constructor que inicializa la ventana para un usuario cliente.
     * Ajusta la visibilidad de botones y pestañas según los permisos del rol.
     * 
     * @param usuario Usuario autenticado con rol cliente.
     */
    public VentanaCliente(Usuario usuario) {
        super(usuario);
        
        // Deshabilitar lo que no pueden hacer los clientes
        btnNuevoCliente.setVisible(false);
        btnNuevoAdmFondo.setVisible(false);
        btnNuevoAsociadoCivil.setVisible(false);
        registrarse.setVisible(false);
        btnEliminarUsuario.setVisible(false);
        
         // Ocultar pestañas que no deben ver
        JTabbedPane tabs = getTabbedPane();
        for (javax.swing.event.ChangeListener listener : tabs.getChangeListeners()) {
            tabs.removeChangeListener(listener);
        } 
        // Las pestañas en el orden del tabbedPane son:
        // 0: Clientes
        // 1: Empleados
        // 2: Adm. Fondos
        // 3: Asociados Civiles
        tabs.removeTabAt(3); // Eliminar Asociados Civiles
        tabs.removeTabAt(2); // Eliminar Adm. Fondos
    }
}
