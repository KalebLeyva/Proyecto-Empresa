/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unidad2;
/**
 * Clase utilitaria para gestionar conexiones a bases de datos MySQL.
 * Proporciona métodos para obtener conexiones a distintas bases de datos
 * configuradas (sistema_login, sistema_gestion) con parámetros personalizados.
 * 
 * También incluye manejo básico de errores con diálogos para informar al usuario.
 * 
 * @author Eduardo Yael/Kaleb Daniel
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import javax.swing.JOptionPane;

public class ConexionMySQL {
    private static final String HOST = "localhost";
    private static final String PORT = "3306";
    private static final String USER = "root";
    private static final String PASSWORD = "Ferrocarril2004";
    
    static {
        try {
            // Carga explícita del driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            showErrorAndExit("Driver MySQL no encontrado: " + e.getMessage());
        }
    }
    /**
     * Obtiene una conexión a la base de datos 'sistema_login'.
     * 
     * @return Conexión válida a la base de datos sistema_login.
     * @throws SQLException Si falla la conexión.
     */
    public static Connection getLoginConnection() throws SQLException {
        String url = "jdbc:mysql://" + HOST + ":" + PORT + "/sistema_login";
        return DriverManager.getConnection(url, USER, PASSWORD);
    }
    /**
     * Obtiene una conexión a la base de datos 'sistema_gestion' con propiedades
     * adicionales para configuración avanzada (Unicode, zona horaria, SSL, etc.).
     * 
     * En caso de error muestra un diálogo informativo y devuelve null.
     * 
     * @return Conexión válida a sistema_gestion o null si falla la conexión.
     */
     public static Connection getGestionConnection() throws SQLException {
        String url = "jdbc:mysql://" + HOST + ":" + PORT + "/sistema_gestion";
        
        Properties props = new Properties();
        props.setProperty("user", USER);
        props.setProperty("password", PASSWORD);
        props.setProperty("useSSL", "false");
        props.setProperty("allowPublicKeyRetrieval", "true");
        props.setProperty("serverTimezone", "UTC");
        props.setProperty("autoReconnect", "true");
        props.setProperty("verifyServerCertificate", "false");
        
        // Configuración adicional crítica
        props.setProperty("useUnicode", "true");
        props.setProperty("characterEncoding", "UTF-8");
        props.setProperty("jdbcCompliantTruncation", "false");
        
        try {
            Connection conn = DriverManager.getConnection(url, props);
            if (!conn.isValid(3)) {
                conn.close();
                throw new SQLException("La conexión no es válida");
            }
            return conn;
        } catch (SQLException e) {
            showError("Error de conexión:\n" + e.getMessage() + 
                     "\nURL: " + url + 
                     "\nVerifique que MySQL esté corriendo y las credenciales sean correctas");
            return null;
        }
    }
     /**
     * Muestra un diálogo de error crítico y termina la ejecución de la aplicación.
     * 
     * @param message Mensaje a mostrar al usuario.
     */
    private static void showErrorAndExit(String message) {
        JOptionPane.showMessageDialog(null, message, "Error Crítico", JOptionPane.ERROR_MESSAGE);
        System.exit(1);
    }
    /**
     * Muestra un diálogo de error de conexión sin terminar la aplicación.
     * 
     * @param message Mensaje a mostrar al usuario.
     */
    private static void showError(String message) {
        JOptionPane.showMessageDialog(null, message, "Error de Conexión", JOptionPane.ERROR_MESSAGE);
    }
    /**
     * Obtiene una conexión genérica a la base de datos MySQL especificada.
     * 
     * @param database Nombre de la base de datos a la cual conectarse.
     * @return Conexión válida a la base de datos especificada.
     * @throws SQLException Si falla la conexión.
     */
    public static Connection getConnection(String database) throws SQLException {
        String url = "jdbc:mysql://" + HOST + ":" + PORT + "/" + database;
        return DriverManager.getConnection(url, USER, PASSWORD);
    }
}