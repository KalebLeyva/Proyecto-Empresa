/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unidad2;
import java.sql.*;
import java.util.ArrayList;
/**
 * Clase DAO (Data Access Object) para manejar operaciones de base de datos relacionadas
 * con la entidad AsociadoCivil.
 * Proporciona métodos para cargar, guardar y buscar registros de asociados civiles
 * desde y hacia la base de datos MySQL.
 * 
 * @author MSI
 */
public class AsociadoCivilDAO {
    /**
     * Carga todos los registros de asociados civiles desde la base de datos.
     * 
     * @return Una lista con todos los objetos AsociadoCivil encontrados.
     * @throws SQLException Si ocurre un error durante la consulta SQL.
     */
    public static ArrayList<AsociadoCivil> cargarAsociados() throws SQLException {
        ArrayList<AsociadoCivil> lista = new ArrayList<>();
        String query = "SELECT * FROM asociado_civil";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                lista.add(new AsociadoCivil(
                    rs.getString("asociado_civil"),
                    rs.getString("folio_electronico"),
                    rs.getString("nombre"),
                    rs.getInt("num_socios"),
                    rs.getString("tipo_sociedad"),
                    rs.getString("direccion"),
                    rs.getInt("contratos_vigente"),
                    rs.getInt("contratos_no_vigente")
                ));
            }
        }
        return lista;
    }
/**
     * Guarda una lista completa de asociados civiles en la base de datos.
     * Elimina previamente todos los registros existentes y luego inserta los nuevos.
     * 
     * @param lista Lista de objetos AsociadoCivil a guardar.
     * @throws SQLException Si ocurre un error durante las operaciones SQL.
     */
    public static void guardarAsociados(ArrayList<AsociadoCivil> lista) throws SQLException {
        String deleteQuery = "DELETE FROM asociado_civil";
        String insertQuery = "INSERT INTO asociado_civil VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             Statement stmt = conn.createStatement();
             PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {
            
            stmt.executeUpdate(deleteQuery);
            
            for (AsociadoCivil ac : lista) {
                pstmt.setString(1, ac.asociadoCivil);
                pstmt.setString(2, ac.folioElectronico);
                pstmt.setString(3, ac.nombre);
                pstmt.setInt(4, ac.numSocios);
                pstmt.setString(5, ac.tipoSociedad);
                pstmt.setString(6, ac.direccion);
                pstmt.setInt(7, ac.contratosVigente);
                pstmt.setInt(8, ac.contratosNoVigente);
                pstmt.executeUpdate();
            }
        }
    }
    /**
     * Guarda un único objeto AsociadoCivil en la base de datos.
     * 
     * @param asociado El objeto AsociadoCivil a guardar.
     * @throws SQLException Si ocurre un error durante la operación SQL.
     */
    public static void guardarAsociado(AsociadoCivil asociado) throws SQLException {
    String insertQuery = "INSERT INTO asociado_civil VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    
    try (Connection conn = ConexionMySQL.getGestionConnection();
         PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {
        
        pstmt.setString(1, asociado.asociadoCivil);
        pstmt.setString(2, asociado.folioElectronico);
        pstmt.setString(3, asociado.nombre);
        pstmt.setInt(4, asociado.numSocios);
        pstmt.setString(5, asociado.tipoSociedad);
        pstmt.setString(6, asociado.direccion);
        pstmt.setInt(7, asociado.contratosVigente);
        pstmt.setInt(8, asociado.contratosNoVigente);
        
        pstmt.executeUpdate();
    }
}
    /**
     * Busca asociados civiles que coincidan exactamente con la clave acta proporcionada.
     * 
     * @param claveActa La clave o identificador para buscar asociados.
     * @return Lista de asociados civiles que coinciden con la clave.
     * @throws SQLException Si ocurre un error durante la consulta SQL.
     */
    public static ArrayList<AsociadoCivil> buscarAsociadosPorClaveActa(String claveActa) throws SQLException {
    ArrayList<AsociadoCivil> asociados = new ArrayList<>();
    String query = "SELECT * FROM asociado_civil WHERE asociado_civil = ?"; // Cambia esto según tu lógica
    try (Connection conn = ConexionMySQL.getGestionConnection();
         PreparedStatement pstmt = conn.prepareStatement(query)) {
        pstmt.setString(1, claveActa);
        ResultSet rs = pstmt.executeQuery();
        while (rs.next()) {
            asociados.add(new AsociadoCivil(
                rs.getString("asociado_civil"),
                rs.getString("folio_electronico"),
                rs.getString("nombre"),
                rs.getInt("num_socios"),
                rs.getString("tipo_sociedad"),
                rs.getString("direccion"),
                rs.getInt("contratos_vigente"),
                rs.getInt("contratos_no_vigente")
            ));
        }
    }
    return asociados;
}
    /**
     * Busca asociados civiles cuyo nombre contenga la cadena especificada (búsqueda parcial).
     * 
     * @param nombre Cadena a buscar dentro del campo nombre.
     * @return Lista de asociados civiles cuyo nombre contiene el texto especificado.
     * @throws SQLException Si ocurre un error durante la consulta SQL.
     */
    public static ArrayList<AsociadoCivil> buscarAsociadosPorNombre(String nombre) throws SQLException {
    ArrayList<AsociadoCivil> asociados = new ArrayList<>();
    String sql = "SELECT * FROM asociado_civil WHERE nombre LIKE ?";
    
    try (Connection conn = ConexionMySQL.getGestionConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        
        ps.setString(1, "%" + nombre + "%");
        
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                asociados.add(new AsociadoCivil(
                    rs.getString("asociado_civil"),
                    rs.getString("folio_electronico"),
                    rs.getString("nombre"),
                    rs.getInt("num_socios"),
                    rs.getString("tipo_sociedad"),
                    rs.getString("direccion"),
                    rs.getInt("contratos_vigente"),
                    rs.getInt("contratos_no_vigente")
                ));
            }
        }
    }
    return asociados;
}
    /**
     * Busca asociados civiles que coincidan parcialmente con la clave acta y el nombre indicados.
     * 
     * @param claveActa Cadena a buscar en el campo asociado_civil (búsqueda parcial).
     * @param nombre Cadena a buscar en el campo nombre (búsqueda parcial).
     * @return Lista de asociados civiles que coinciden con ambos criterios.
     * @throws SQLException Si ocurre un error durante la consulta SQL.
     */
    public static ArrayList<AsociadoCivil> buscarAsociadosPorClaveActaYNombre(String claveActa, String nombre) throws SQLException {
    ArrayList<AsociadoCivil> asociados = new ArrayList<>();
    String sql = "SELECT * FROM asociado_civil WHERE asociado_civil LIKE ? AND nombre LIKE ?";
    
    try (Connection conn = ConexionMySQL.getGestionConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        
        ps.setString(1, "%" + claveActa + "%");
        ps.setString(2, "%" + nombre + "%");
        
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                asociados.add(new AsociadoCivil(
                    rs.getString("asociado_civil"),
                    rs.getString("folio_electronico"),
                    rs.getString("nombre"),
                    rs.getInt("num_socios"),
                    rs.getString("tipo_sociedad"),
                    rs.getString("direccion"),
                    rs.getInt("contratos_vigente"),
                    rs.getInt("contratos_no_vigente")
                ));
            }
        }
    }
    return asociados;
}
}
