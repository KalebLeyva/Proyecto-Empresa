/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unidad2;
/**
 * Clase DAO para la gestión de objetos Empleado en la base de datos.
 * Proporciona métodos para cargar, buscar, guardar y eliminar empleados
 * usando la conexión a la base de datos configurada en {@link ConexionMySQL}.
 * 
 * @author MSI
 */
import java.sql.*;
import java.util.ArrayList;

public class EmpleadoDAO {
    private static final String TABLA = "empleado";
    
    public static ArrayList<Empleado> cargarEmpleados() throws SQLException {
        ArrayList<Empleado> lista = new ArrayList<>();
        String query = "SELECT * FROM " + TABLA;
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                lista.add(new Empleado(
                    rs.getString("curp"),
                    rs.getString("nombre"),
                    rs.getString("apellidos"),
                    rs.getString("correo"),
                    rs.getString("telefono"),
                    rs.getString("direccion"),
                    rs.getString("num_cuenta"),
                    rs.getString("tipo_banco"),
                    rs.getString("socio"),
                    rs.getString("empleado_de"),
                    rs.getDouble("salario")
                ));
            }
        }
        return lista;
    }

    public static ArrayList<Empleado> buscarEmpleadosPorClaveActa(String claveActa) throws SQLException {
        ArrayList<Empleado> lista = new ArrayList<>();
        String query = "SELECT * FROM " + TABLA + " WHERE empleado_de LIKE ?";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, "%" + claveActa + "%");
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                lista.add(new Empleado(
                    rs.getString("curp"),
                    rs.getString("nombre"),
                    rs.getString("apellidos"),
                    rs.getString("correo"),
                    rs.getString("telefono"),
                    rs.getString("direccion"),
                    rs.getString("num_cuenta"),
                    rs.getString("tipo_banco"),
                    rs.getString("socio"),
                    rs.getString("empleado_de"),
                    rs.getDouble("salario")
                ));
            }
        }
        return lista;
    }
    
    public static void guardarEmpleado(Empleado empleado) throws SQLException {
        String query = "INSERT INTO " + TABLA + " (curp, nombre, apellidos, correo, " +
                      "telefono, direccion, num_cuenta, tipo_banco, socio, empleado_de, salario) " +
                      "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, empleado.curp);
            pstmt.setString(2, empleado.nombre);
            pstmt.setString(3, empleado.apellidos);
            pstmt.setString(4, empleado.correo);
            pstmt.setString(5, empleado.telefono);
            pstmt.setString(6, empleado.direccion);
            pstmt.setString(7, empleado.numCuenta);
            pstmt.setString(8, empleado.tipoBanco);
            pstmt.setString(9, empleado.socio);
            pstmt.setString(10, empleado.empleadoDe);
            pstmt.setDouble(11, empleado.salario);
            
            pstmt.executeUpdate();
        }
    }

    public static void guardarEmpleados(ArrayList<Empleado> lista) throws SQLException {
        String deleteQuery = "DELETE FROM " + TABLA;
        String insertQuery = "INSERT INTO " + TABLA + " (curp, nombre, apellidos, correo, " +
                           "telefono, direccion, num_cuenta, tipo_banco, socio, empleado_de, salario) " +
                           "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             Statement stmt = conn.createStatement();
             PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {
            
            stmt.executeUpdate(deleteQuery);
            
            for (Empleado emp : lista) {
                pstmt.setString(1, emp.curp);
                pstmt.setString(2, emp.nombre);
                pstmt.setString(3, emp.apellidos);
                pstmt.setString(4, emp.correo);
                pstmt.setString(5, emp.telefono);
                pstmt.setString(6, emp.direccion);
                pstmt.setString(7, emp.numCuenta);
                pstmt.setString(8, emp.tipoBanco);
                pstmt.setString(9, emp.socio);
                pstmt.setString(10, emp.empleadoDe);
                pstmt.setDouble(11, emp.salario);
                pstmt.addBatch();
            }
            pstmt.executeBatch();
        }
    }
    
    public static void eliminarEmpleado(String curp) throws SQLException {
        String query = "DELETE FROM " + TABLA + " WHERE curp = ?";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, curp);
            pstmt.executeUpdate();
        }
    }
    
    public static ArrayList<Empleado> cargarEmpleadosPorEmpresa(String claveActa) throws SQLException {
        if (claveActa == null || claveActa.trim().isEmpty()) {
            throw new IllegalArgumentException("La clave de acta no puede ser nula o vacía");
        }
        
        ArrayList<Empleado> lista = new ArrayList<>();
        String query = "SELECT * FROM " + TABLA + " WHERE empleado_de = ?";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, claveActa);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                lista.add(new Empleado(
                    rs.getString("curp"),
                    rs.getString("nombre"),
                    rs.getString("apellidos"),
                    rs.getString("correo"),
                    rs.getString("telefono"),
                    rs.getString("direccion"),
                    rs.getString("num_cuenta"),
                    rs.getString("tipo_banco"),
                    rs.getString("socio"),
                    rs.getString("empleado_de"),
                    rs.getDouble("salario")
                ));
            }
        }
        return lista;
    }
    
    public static boolean existeEmpleado(String curp) throws SQLException {
        String query = "SELECT COUNT(*) FROM " + TABLA + " WHERE curp = ?";
        
        try (Connection conn = ConexionMySQL.getGestionConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, curp);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }
    public static ArrayList<Empleado> buscarEmpleadosPorNombre(String nombre) throws SQLException {
    ArrayList<Empleado> empleados = new ArrayList<>();
    String sql = "SELECT * FROM empleado WHERE nombre LIKE ?";
    
    try (Connection conn = ConexionMySQL.getGestionConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        
        ps.setString(1, "%" + nombre + "%");
        
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                empleados.add(new Empleado(
                    rs.getString("curp"),
                    rs.getString("nombre"),
                    rs.getString("apellidos"),
                    rs.getString("correo"),
                    rs.getString("telefono"),
                    rs.getString("direccion"),
                    rs.getString("num_cuenta"),
                    rs.getString("tipo_banco"),
                    rs.getString("socio"),
                    rs.getString("empleado_de"),
                    rs.getDouble("salario")
                ));
            }
        }
    }
    return empleados;
}
    public static ArrayList<Empleado> buscarEmpleadosPorClaveActaYNombre(String claveActa, String nombre) throws SQLException {
    ArrayList<Empleado> empleados = new ArrayList<>();
    String sql = "SELECT * FROM empleado WHERE empleado_de LIKE ? AND nombre LIKE ?";
    
    try (Connection conn = ConexionMySQL.getGestionConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        
        ps.setString(1, "%" + claveActa + "%");
        ps.setString(2, "%" + nombre + "%");
        
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                empleados.add(new Empleado(
                    rs.getString("curp"),
                    rs.getString("nombre"),
                    rs.getString("apellidos"),
                    rs.getString("correo"),
                    rs.getString("telefono"),
                    rs.getString("direccion"),
                    rs.getString("num_cuenta"),
                    rs.getString("tipo_banco"),
                    rs.getString("socio"),
                    rs.getString("empleado_de"),
                    rs.getDouble("salario")
                ));
            }
        }
    }
    return empleados;
}
}